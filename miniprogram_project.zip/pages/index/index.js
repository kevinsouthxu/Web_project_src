//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    username:"",
    password:"",
    error:""
  },
  onLoad:function(){
  },
  //用户名
  Inputusername:function(event){
      this.setData({username:event.detail.value})
  },
  Inputpassword:function(event){
    this.setData({password:event.detail.value})
  },
  login:function(){
    var that = this;
    wx.request({
      url:'http://localhost:8080/login',
      method:"POST",
      data:{
        username:this.data.username,
        password:this.data.password
      },
      header:{
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res){
        if(res.data!=-1){
            console.log("yes");
            console.log(res);
            app.globalData.userLogin = true;
            wx.setStorageSync('token', res);
            wx.navigateTo({
              url:'../book/book?item='+0,
            })
        }
        else{
          that.setData({error:"用户名或密码错误"});
        }
      }
    });
  },
})
