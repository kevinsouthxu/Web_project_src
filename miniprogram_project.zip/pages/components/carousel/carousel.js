// pages/components/carousel.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    carouseImg:Array,
  },

  /**
   * 组件的初始数据
   */
  data: {
    currindex:0
  },

  /**
   * 组件的方法列表
   */
  methods: {
    swip(e){
      this.setData({
        currindex:e.detail.currindex
      });
    }
  }
})
