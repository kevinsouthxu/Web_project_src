// pages/components/CardSet/CardSet.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    books:Array,
  },

  
  /**
   * 组件的初始数据
   */
  data: {
  },
  /**
   * 组件的方法列表
   */
  methods: {
    click:function(event){
      var id = event.currentTarget.dataset.num;
      wx.navigateTo({
        url:'../../../../bookinformation/bookinformation?bookId='+id
      })
    },
  }
})
