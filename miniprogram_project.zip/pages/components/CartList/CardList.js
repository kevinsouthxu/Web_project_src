// pages/components/CartList/CardList.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    CartItem:Array,
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    clickIncrease:function(event){
      var id = event.currentTarget.dataset.num;
      console.log(id);
    var that = this;
    var token = wx.getStorageSync('token').data;
    wx.request({
      url:'http://localhost:8080/increaseCart',
      method:"POST",
      data:{
        token:token,
        bookId:id,
        num:1
      },
      header:{
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res){
        if(res.statusCode==200){
            console.log(res);
            if(res.data == true){
              console.log('成功增加')
              that.triggerEvent('onChangeArray',{sonParam:true});
            }
        }
        else{
          console.log("数据获取失败");
          console.log(res);
        }
      }
    });
    },
    clickDecrease:function(event){
      var id = event.currentTarget.dataset.num;
      console.log(id);
    var that = this;
    var token = wx.getStorageSync('token').data;
    wx.request({
      url:'http://localhost:8080/decreaseCart',
      method:"POST",
      data:{
        token:token,
        bookId:id,
        num:1
      },
      header:{
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res){
        if(res.statusCode==200){
            console.log(res);
            if(res.data == true){
              console.log('成功减少')
              that.triggerEvent('onChangeArray',{sonParam:true});
            }
        }
        else{
          console.log("数据获取失败");
          console.log(res);
        }
      }
    });
    },
  }
})
