// pages/cart/cart.js
import Notify  from "../../miniprogram_npm/vant-weapp/notify/notify";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active:0,
    cartList:[],
    price:0,
  },
  onChange:function(event){
    if(event.detail==0)
    wx.redirectTo({
      url:'../book/book?item='+0,
    });
  },
  onSubmit:function(){
    var that = this;
    var token = wx.getStorageSync('token').data;
    wx.request({
      url:'http://localhost:8080/addOrdermemory',
      method:"POST",
      data:{
        token:token
      },
      header:{
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res){
        if(res.statusCode==200){
          if(res.data ==true)
          {
            Notify({backgroundColor:'green',text:'下单成功'});
            that.getCart();
          }
          else
          {
            Notify({backgroundColor:'red',text:'下单失败'});
          }
        }
        else{
          console.log("数据获取失败");
          console.log(res);
        }
      }
    });
  },
  ChangeArray:function(event){
    this.getCart();
  },
  getCart:function(){
    var that = this;
    var token = wx.getStorageSync('token').data;
    wx.request({
      url:'http://localhost:8080/getCart',
      method:"POST",
      data:{
        token:token
      },
      header:{
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res){
        if(res.statusCode==200){
          console.log(res.data);
          let price = 0;
          if(res.data.length==0){
            that.data.cartList.splice(0,that.data.cartList.length);
          }
          for(let i = 0;i < that.data.cartList.length;i++){
            if(i>= res.data.length || res.data[i].bookId != that.data.cartList[i].bookId){
              that.data.cartList.splice(i,1);
              break;
            }
          }
            for(let i = 0;i < res.data.length;i++){
              if(res.data[i].bookId == that.data.cartList[i].bookId){
                that.data.cartList[i].bookCount = res.data[i].bookCount;price += parseInt(that.data.cartList[i].price.substring(1)) * that.data.cartList[i].bookCount;
              }
            }
            that.setData({cartList:that.data.cartList});
            that.setData({price:price*100});
            console.log(that.data.cartList);
        }
        else{
          console.log("数据获取失败");
          console.log(res);
        }
      }
    });
  },
  getBooks:function(){
    var that = this;
    var books = [];
    for(let i = 0;i < this.data.cartList.length;i++){
      books.push(this.data.cartList[i].bookId);
    }
    wx.request({
      url:'http://localhost:8080/findBooks',
      method:"POST",
      data:{
        books:books
      },
      header:{
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res){
        if(res.statusCode==200){
            let price = 0;
            for(let i = 0;i < that.data.cartList.length;i++){
              that.data.cartList[i].name = res.data[i].name;
              that.data.cartList[i].author = res.data[i].author;
              that.data.cartList[i].price = res.data[i].price;
              that.data.cartList[i].image = res.data[i].image.base64;
              price += parseInt(that.data.cartList[i].price.substring(1)) * that.data.cartList[i].bookCount;
            }
            that.setData({cartList:that.data.cartList});
            that.setData({price:price*100});
        }
        else{
          console.log("数据获取失败");
          console.log(res);
        }
      }
    });
  },
  onChange:function(event){
    if(event.detail==0)
    wx.redirectTo({
      url:'../book/book?item='+0,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({active:parseInt(options.item)});
    var that = this;
    var token = wx.getStorageSync('token').data;
    wx.request({
      url:'http://localhost:8080/getCart',
      method:"POST",
      data:{
        token:token
      },
      header:{
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res){
        if(res.statusCode==200){
            that.setData({cartList:res.data});
            that.getBooks();
        }
        else{
          console.log("数据获取失败");
          console.log(res);
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})