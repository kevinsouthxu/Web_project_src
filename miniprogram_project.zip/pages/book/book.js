const app = getApp()

Page({
  data:{
    books:[],
    carouseImg:[
      "../../img/1.jpg",
      "../../img/2.jpg",
      "../../img/3.jpg",
      "../../img/4.jpg",
    ],
    searchValue:"",
  },
  onLoad:function(){
    var that = this;
    wx.request({
      url:'http://localhost:8080/getBooks',
      method:"GET",
      data:{
        username:this.data.username,
        password:this.data.password
      },
      success(res){
        if(res.statusCode == 200){
            console.log(res);
            that.setData({books:res.data});
            console.log(that.data.books);
        }
        else{
          console.log("获取书籍失败");
        }
      }
    });
  },
})