const app = getApp()

Page({
  data:{
    originbooks:[],
    books:[],
    carouseImg:[
      "../../img/1.jpg",
      "../../img/2.jpg",
      "../../img/3.jpg",
      "../../img/4.jpg",
    ],
    searchValue:"",
  },
  onSearch:function(val) {
    console.log(val);
    this.setData({searchValue:val.detail});
    var tempbooks = [];
    for(let i = 0;i < this.data.originbooks.length;i++){
        if(this.data.originbooks[i].name.indexOf(this.data.searchValue)!== -1
          || this.data.originbooks[i].author.indexOf(this.data.searchValue)!== -1
          || this.data.originbooks[i].price.indexOf(this.data.searchValue)!== -1){
          tempbooks.push(this.data.originbooks[i]);
        }
    }
    this.setData({books:tempbooks});
  },
  onCancel:function() {
    console.log('取消');
    this.setData({searchValue:""});
    this.setData({books:this.data.originbooks});
  },
  onLoad:function(){
    var that = this;
    wx.request({
      url:'http://localhost:8080/getBooks',
      method:"GET",
      data:{
        username:this.data.username,
        password:this.data.password
      },
      success(res){
        if(res.statusCode == 200){
            console.log(res);
            that.setData({books:res.data});
            that.setData({originbooks:res.data});
            console.log(that.data.books);
        }
        else{
          console.log("获取书籍失败");
        }
      }
    });
  },
})