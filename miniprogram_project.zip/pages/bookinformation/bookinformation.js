// pages/bookinformation/bookinformation.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bookId:0,
    bookdata:{},
    activeNames: ['1'],
    error:"",
  },
  onChange:function (event) {
    this.setData({
      activeNames: event.detail,
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({bookId:options.bookId});
    console.log(this.data.bookId);
    var that = this;
    wx.request({
      url:'http://localhost:8080/findBook/'+this.data.bookId,
      method:"GET",
      success(res){
        if(res.statusCode == 200){
            console.log(res);
            that.setData({bookdata:res.data});
            console.log(that.data.bookdata);
        }
        else{
          console.log("获取书籍错误");
          that.setData({error:"获取书籍错误"});
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})