import Notify  from "../../miniprogram_npm/vant-weapp/notify/notify";

// pages/bookinformation/bookinformation.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bookId:0,
    bookdata:{},
    activeNames: ['1'],
    error:"",
  },
  onChange:function (event) {
    this.setData({
      activeNames: event.detail,
    });
  },
  onClickButton:function () {
    console.log(this.data.bookId);
    var that = this;
    var token = wx.getStorageSync('token').data;
    console.log(token);
    wx.request({
      url:'http://localhost:8080/addCart',
      method:"POST",
      data:{
        token:token,
        bookId:this.data.bookId
      },
      header:{
        'content-type': 'application/x-www-form-urlencoded'
      },
      success(res){
        if(res.data==true){
            Notify({backgroundColor:'green',text:'成功加入到购物车'});
        }
        else{
          if(res.data == false)
            Notify({backgroundColor:'#fa8c16',text:'购物车已有该书籍'});
          else
            Notify({backgroundColor:'red',text:'发生未知错误'});
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({bookId:options.bookId});
    console.log(this.data.bookId);
    var that = this;
    wx.request({
      url:'http://localhost:8080/findBook/'+this.data.bookId,
      method:"GET",
      success(res){
        if(res.statusCode == 200){
            console.log(res);
            that.setData({bookdata:res.data});
            console.log(that.data.bookdata);
        }
        else{
          console.log("获取书籍错误");
          that.setData({error:"获取书籍错误"});
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})