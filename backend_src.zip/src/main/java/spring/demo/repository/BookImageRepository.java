package spring.demo.repository;

import spring.demo.entity.BookImage;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface BookImageRepository extends MongoRepository<BookImage, Integer>{
}
