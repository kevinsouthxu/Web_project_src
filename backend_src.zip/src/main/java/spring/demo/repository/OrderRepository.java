package spring.demo.repository;

import org.springframework.data.jpa.repository.Query;
import spring.demo.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepository extends JpaRepository <Order,Integer> {

    @Query("select o from Order o")
    List<Order> getOrders();


}
