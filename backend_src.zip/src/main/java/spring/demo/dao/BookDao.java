package spring.demo.dao;

import spring.demo.entity.Book;
import spring.demo.entity.Order;

import java.util.List;
public interface BookDao {
    Book findOne(Integer id);
    void saveOne(Book b);
    Boolean changeImage(Integer id,String base64);
    List<Book> getBooks();
}
