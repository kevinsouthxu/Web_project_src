package spring.demo.dao;

import spring.demo.entity.OrderItem;
import spring.demo.entity.User;
public interface UserDao {
    User findOne(Integer id);
    User checkUser(String username, String password);
    void saveOne(User item);
}
