package spring.demo.dao;

import spring.demo.entity.User;
public interface UserDao {
    User findOne(Integer id);
    User checkUser(String username, String password);
    User getUserbyUsername(String username);
    User getUserbyEmail(String email);
    void saveOne(User item);
    void saveOneNotFlush(User item);
}
