package spring.demo.dao;

import spring.demo.entity.Order;
import spring.demo.entity.OrderItem;

public interface OrderDao {
    Order findOne(Integer id);
    void saveOne(Order order);
    void deleteOne(Order item);
}
