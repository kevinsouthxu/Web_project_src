package spring.demo.dao;


import spring.demo.entity.Order;
import spring.demo.entity.OrderItem;

import java.util.List;

public interface OrderDao {
    Order findOne(Integer id);
    List<Order> getOrders();
    void saveOne(Order order);
    void deleteOne(Order item);
}
