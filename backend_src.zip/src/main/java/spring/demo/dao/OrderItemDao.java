package spring.demo.dao;

import spring.demo.entity.OrderItem;

public interface OrderItemDao {
    OrderItem findOne(Integer id);
    void saveOne(OrderItem item);
    void deleteOne(OrderItem item);
    void deleteOneById(int id);
}
