package spring.demo.SessionManage;

import com.mongodb.util.JSON;
import net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class cart {
    static private List<cartItems> cartItemsList = new ArrayList<>();
    static public boolean addCart(int bookId){
        for(int i = 0;i < cartItemsList.size();i++){
            if(cartItemsList.get(i).getBookId() == bookId)
                return false;
        }
        cartItems Item = new cartItems();
        Item.setBookId(bookId);
        Item.setBookNum(1);
        cartItemsList.add(Item);
        return true;
    }
    static public boolean deleteCart(int bookId){
        for(int i = 0;i < cartItemsList.size();i++){
            if(cartItemsList.get(i).getBookId() == bookId)
            {
                cartItemsList.remove(i);
                return true;
            }
        }
        return false;
    }
    static public boolean increaseCart(int bookId,int num){
        for(int i = 0;i < cartItemsList.size();i++){
            if(cartItemsList.get(i).getBookId() == bookId)
            {
                cartItems Item = cartItemsList.get(i);
                Item.setBookNum(Item.getBookNum()+num);
                cartItemsList.set(i,Item);
                return true;
            }
        }
        return false;
    }
    static public boolean decreaseCart(int bookId,int num){
        for(int i = 0;i < cartItemsList.size();i++){
            if(cartItemsList.get(i).getBookId() == bookId)
            {
                cartItems Item = cartItemsList.get(i);
                if((Item.getBookNum()-num) < 0)
                    return false;
                if((Item.getBookNum() - num) == 0)
                {
                    return deleteCart(bookId);
                }
                Item.setBookNum(Item.getBookNum()-num);
                cartItemsList.set(i,Item);
                return true;
            }
        }
        return false;
    }
    static public List CartJson() {
        List<JSONObject> JsonList = new ArrayList<>();
        for (int i = 0; i < cartItemsList.size(); i++) {
            JSONObject object = new JSONObject();
            object.put("bookId",cartItemsList.get(i).getBookId());
            object.put("bookCount",cartItemsList.get(i).getBookNum());
            JsonList.add(object);
        }
        return JsonList;
    }
    static public void cleanCart(){
        cartItemsList.clear();
    }
}
