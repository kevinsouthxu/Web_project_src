package spring.demo.SessionManage;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.lang.Math;



public class SessionManager {
    static private Map<Long,Integer> tokens = new TreeMap<>();
    static private Random randomGenerator = new Random();
    static public boolean setToken(int userid){
        for(Map.Entry<Long,Integer> e : tokens.entrySet())
        {
            if(e.getValue().equals(userid))
                return false;
        }
        long token = 0;
        while(token < 10000)
        {
            token = Math.abs(randomGenerator.nextInt());
        }
        tokens.put(token,userid);
        return true;
    }
    static public boolean removeToken(long token){
        if(tokens.containsKey(token))
        {
            tokens.remove(token);
            return true;
        }
        return false;
    }
    static public long getToken(int userid){
        for(Map.Entry<Long,Integer> e : tokens.entrySet())
        {
            if(e.getValue().equals(userid))
                return e.getKey();
        }
        return -1;
    }
    static public int getuserId(long token){
        return tokens.get(token);
    }
}
