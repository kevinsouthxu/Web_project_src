package spring.demo.SessionManage;
import net.minidev.json.JSONObject;
import org.hibernate.Session;

import java.util.*;
import spring.demo.SessionManage.*;
import java.lang.Math;

public class SessionManager {
    static private Map<Long,Integer> tokens = new TreeMap<>();
    static private Map<Integer,cart> carts = new TreeMap<>();
    static private Random randomGenerator = new Random();
    static public boolean addCart(long token,int bookId){
        if(tokens.containsKey(token) && carts.containsKey(tokens.get(token))){
            cart acart = carts.get(tokens.get(token));
            boolean whether = acart.addCart(bookId);
            if(whether)
                carts.put(tokens.get(token),acart);
            return whether;
        }
        cart bcart = new cart();
        boolean flag = bcart.addCart(bookId);
        if(flag)
            carts.put(tokens.get(token),bcart);
        return flag;
    }
    static public boolean deleteCart(long token,int bookId){
        if(tokens.containsKey(token) && carts.containsKey(tokens.get(token))){
            cart acart = carts.get(tokens.get(token));
            boolean whether = acart.deleteCart(bookId);
            if(whether)
                carts.put(tokens.get(token),acart);
            return whether;
        }
        cart bcart = new cart();
        boolean flag = bcart.deleteCart(bookId);
        if(flag)
            carts.put(tokens.get(token),bcart);
        return flag;
    }
    static public boolean increaseCart(long token,int bookId,int num){
        if(tokens.containsKey(token) && carts.containsKey(tokens.get(token))){
            cart acart = carts.get(tokens.get(token));
            boolean whether = acart.increaseCart(bookId,num);
            if(whether)
                carts.put(tokens.get(token),acart);
            return whether;
        }
        return false;
    }
    static public boolean decreaseCart(long token,int bookId,int num){
        if(tokens.containsKey(token) && carts.containsKey(tokens.get(token))){
            cart acart = carts.get(tokens.get(token));
            boolean whether = acart.decreaseCart(bookId,num);
            if(whether)
                carts.put(tokens.get(token),acart);
            return whether;
        }
        return false;
    }
    static public List getCart(long token){
        if(tokens.containsKey(token) && carts.containsKey(tokens.get(token))){
            System.out.println("have this token");
            return carts.get(tokens.get(token)).CartJson();
        }
        System.out.println("dont have!");
        List<JSONObject> Jsonlist = new ArrayList<>();
        return Jsonlist;
    }
    static public void cleanCart(long token){
        if(tokens.containsKey(token) && carts.containsKey(tokens.get(token))){
            carts.get(tokens.get(token)).cleanCart();
        }
    }

    static public boolean setToken(int userid){
        for(Map.Entry<Long,Integer> e : tokens.entrySet())
        {
            if(e.getValue().equals(userid))
                return false;
        }
        long token = 0;
        while(token < 10000)
        {
            token = Math.abs(randomGenerator.nextInt());
        }
        tokens.put(token,userid);
        return true;
    }
    static public boolean setTokenAdmin(int userid){
        for(Map.Entry<Long,Integer> e : tokens.entrySet())
        {
            if(e.getValue().equals(userid))
                return false;
        }
        long token = 0;
        while(token > 10000 || token <= 0)
        {
            token = Math.abs(randomGenerator.nextInt());
        }
        tokens.put(token,userid);
        return true;
    }
    static public boolean removeToken(long token){
        if(tokens.containsKey(token))
        {
            tokens.remove(token);
            return true;
        }
        return false;
    }
    static public long getToken(int userid){
        for(Map.Entry<Long,Integer> e : tokens.entrySet())
        {
            if(e.getValue().equals(userid))
                return e.getKey();
        }
        return -1;
    }
    static public int getuserId(long token){
        if(tokens.containsKey(token)){
            return tokens.get(token);
        }
        return -1;
    }
}
