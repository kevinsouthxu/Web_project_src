package spring.demo.SessionManage;

public class cartItems {
    private int bookId;
    private int bookNum;
    public int getBookId(){
        return bookId;
    }
    public void setBookId(int id){
        this.bookId = id;
    }
    public int getBookNum(){
        return bookNum;
    }
    public void setBookNum(int num){
        this.bookNum = num;
    }
}
