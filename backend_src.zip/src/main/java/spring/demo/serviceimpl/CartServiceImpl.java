package spring.demo.serviceimpl;

import org.springframework.stereotype.Service;
import spring.demo.SessionManage.SessionManager;
import spring.demo.service.CartService;
import spring.demo.SessionManage.cart;

import java.util.List;

@Service
public class CartServiceImpl implements CartService {
    @Override
    public boolean addCart(long token,int bookId){
        SessionManager manage = new SessionManager();
        boolean flag = manage.addCart(token,bookId);
        return flag;
    }
    @Override
    public boolean deleteCart(long token,int bookId){
        SessionManager manage = new SessionManager();
        boolean flag = manage.deleteCart(token,bookId);
        return flag;
    }
    @Override
    public boolean increaseCart(long token,int bookId,int num){
        SessionManager manage = new SessionManager();
        boolean flag = manage.increaseCart(token,bookId,num);
        return flag;
    }
    @Override
    public boolean decreaseCart(long token,int bookId,int num){
        SessionManager manage = new SessionManager();
        boolean flag = manage.decreaseCart(token,bookId,num);
        return flag;
    }
    @Override
    public List getCart(long token){
        SessionManager manage = new SessionManager();
        return manage.getCart(token);
    }
}
