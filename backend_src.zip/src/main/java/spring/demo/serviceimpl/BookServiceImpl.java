package spring.demo.serviceimpl;

import spring.demo.dao.BookDao;
import spring.demo.entity.Book;
import spring.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookServiceImpl implements BookService{
    @Autowired
    private BookDao bookDao;

    @Override
    public List<Book> getBooks(){  return bookDao.getBooks();}

    @Override
    public Book findBookById(Integer id){
        return bookDao.findOne(id);
    }

    @Override
    public List<Book> findBooks(List<Integer> books)
    {
        List<Book> bookList = new ArrayList<>();
        for(int i = 0;i < books.size();i++)
        {
            bookList.add(bookDao.findOne(books.get(i)));
        }
        return bookList;
    }
}
