package spring.demo.serviceimpl;

import net.minidev.json.JSONObject;
import spring.demo.Errormessage.ErrorMessage;
import spring.demo.Successmessage.SuccessMessage;
import spring.demo.dao.BookDao;
import spring.demo.entity.Book;
import spring.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class BookServiceImpl implements BookService{
    @Autowired
    private BookDao bookDao;

    @Override
    public List<Book> getBooks(){  return bookDao.getBooks();}

    @Override
    public Book findBookById(Integer id){
        return bookDao.findOne(id);
    }

    @Override
    public List<Book> findBooks(List<Integer> books)
    {
        List<Book> bookList = new ArrayList<>();
        for(int i = 0;i < books.size();i++)
        {
            bookList.add(bookDao.findOne(books.get(i)));
        }
        return bookList;
    }
    @Override
    public JSONObject changeBook(Map<String, String> map){
        JSONObject object = new JSONObject();
        if(!map.containsKey("Id")){
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setErrortype(6);
            object = errorMessage.getMessage();
            return object;
        }
        int id = Integer.parseInt(map.get("Id"));
        Book book = bookDao.findOne(id);
        if(String.valueOf(book).equals("null")){
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setErrortype(5);
            object = errorMessage.getMessage();
            return object;
        }
        for(Map.Entry<String, String> entry : map.entrySet()){
            String mapKey = entry.getKey();
            String mapValue = entry.getValue();
            if(mapKey.equals("name")){
                book.setName(mapValue);
            }
            if(mapKey.equals("author")){
                book.setAuthor(mapValue);
            }
            if(mapKey.equals("price")){
                book.setPrice(mapValue);
            }
            if(mapKey.equals("ISBN")){
                book.setISBN(mapValue);
            }
            if(mapKey.equals("repertory")){
                book.setRepertory(Integer.parseInt(mapValue));
            }
            if(mapKey.equals("information")){
                book.setInformation(mapValue);
            }
            if(mapKey.equals("image")){
                bookDao.changeImage(id,mapValue);
            }

        }
        bookDao.saveOne(book);
        SuccessMessage successMessage = new SuccessMessage();
        successMessage.setSuccesstype(3);
        object = successMessage.getMessage();
        return object;
    }

    @Override
    public JSONObject createBook(Map<String, String> map){
        JSONObject object = new JSONObject();
        Book book = new Book();
        String base64="";
        for(Map.Entry<String, String> entry : map.entrySet()){
            String mapKey = entry.getKey();
            String mapValue = entry.getValue();
            if(mapKey.equals("name")){
                book.setName(mapValue);
            }
            if(mapKey.equals("author")){
                book.setAuthor(mapValue);
            }
            if(mapKey.equals("price")){
                book.setPrice(mapValue);
            }
            if(mapKey.equals("ISBN")){
                book.setISBN(mapValue);
            }
            if(mapKey.equals("repertory")){
                book.setRepertory(Integer.parseInt(mapValue));
            }
            if(mapKey.equals("information")){
                book.setInformation(mapValue);
            }
            if(mapKey.equals("image")){
                base64 = mapValue;
            }

        }
        bookDao.saveOne(book);
        book.setNumber(book.getBookId());
        bookDao.createImage(book.getBookId(),base64);
        bookDao.saveOne(book);
        SuccessMessage successMessage = new SuccessMessage();
        successMessage.setSuccesstype(4);
        object = successMessage.getMessage();
        return object;
    }

    @Override
    public JSONObject deleteBook(Integer bookId) {
        JSONObject object = new JSONObject();
        Book book = bookDao.findOne(bookId);
        if(String.valueOf(book).equals("null")){
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setErrortype(5);
            object = errorMessage.getMessage();
            return object;
        }
        bookDao.deleteOneById(bookId);
        SuccessMessage successMessage = new SuccessMessage();
        successMessage.setSuccesstype(5);
        object = successMessage.getMessage();
        return object;
    }
}
