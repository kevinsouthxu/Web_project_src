package spring.demo.serviceimpl;

import net.minidev.json.JSONObject;
import spring.demo.Errormessage.ErrorMessage;
import spring.demo.Successmessage.SuccessMessage;
import spring.demo.dao.BookDao;
import spring.demo.entity.Book;
import spring.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class BookServiceImpl implements BookService{
    @Autowired
    private BookDao bookDao;

    @Override
    public List<Book> getBooks(){  return bookDao.getBooks();}

    @Override
    public Book findBookById(Integer id){
        return bookDao.findOne(id);
    }

    @Override
    public List<Book> findBooks(List<Integer> books)
    {
        List<Book> bookList = new ArrayList<>();
        for(int i = 0;i < books.size();i++)
        {
            bookList.add(bookDao.findOne(books.get(i)));
        }
        return bookList;
    }
    @Override
    public JSONObject changeBook(Map<String, String> map){
        JSONObject object = new JSONObject();
        if(!map.containsKey("Id")){
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setErrortype(6);
            object = errorMessage.getMessage();
            return object;
        }
        int id = Integer.parseInt(map.get("Id"));
        Book book = bookDao.findOne(id);
        if(String.valueOf(book).equals("null")){
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setErrortype(5);
            object = errorMessage.getMessage();
            return object;
        }
        for(Map.Entry<String, String> entry : map.entrySet()){
            String mapKey = entry.getKey();
            String mapValue = entry.getValue();
            System.out.println(mapKey+":"+mapValue);
            if(mapKey == "name"){
                book.setName(mapValue);
            }
            if(mapKey == "author"){
                book.setAuthor(mapValue);
            }
            if(mapKey == "price"){
                book.setPrice(mapValue);
            }
            if(mapKey == "ISBN"){
                book.setISBN(mapValue);
            }
            if(mapKey == "repertory"){
                book.setRepertory(Integer.parseInt(mapValue));
            }
            if(mapKey == "information"){
                book.setInformation(mapValue);
            }

        }
        bookDao.saveOne(book);
        SuccessMessage successMessage = new SuccessMessage();
        successMessage.setSuccesstype(3);
        object = successMessage.getMessage();
        return object;
    }
}
