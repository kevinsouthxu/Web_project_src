package spring.demo.serviceimpl;
import net.minidev.json.JSONObject;
import spring.demo.dao.UserDao;
import spring.demo.service.UserService;
import spring.demo.entity.User;
import spring.demo.Errormessage.ErrorMessage;
import spring.demo.Successmessage.SuccessMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import spring.demo.SessionManage.SessionManager;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserDao userDao;

    @Override
    public User findUserById(Integer id){
        return userDao.findOne(id);
    }

    @Override
    public User checkUser(String username, String password){
        User user = userDao.checkUser(username,password);
        System.out.println(String.valueOf(user));
        return user;
    }

    @Override
    public User checkUserBytoken(long token){
        SessionManager manage = new SessionManager();
        int userid = manage.getuserId(token);
        User user = userDao.findOne(userid);
        return user;
    }

    @Override
    public long login(String username, String password){
        SessionManager manage = new SessionManager();
        User user = userDao.checkUser(username,password);
        String userString = String.valueOf(user);
        if(userString != "null")
        {
            if(user.getIsBan()){
                return 0;
            }
            if(!user.getIsAdmin()) {
                if (manage.setToken(user.getUserId())) {
                    long token = manage.getToken(user.getUserId());
                    return token;
                } else {
                    long token = manage.getToken(user.getUserId());
                    return token;
                }
            }
            else{
                if (manage.setTokenAdmin(user.getUserId())) {
                    long token = manage.getToken(user.getUserId());
                    return token;
                } else {
                    long token = manage.getToken(user.getUserId());
                    return token;
                }
            }
        }
        return -1;
    }

    @Override
    public boolean logout(long token){
        SessionManager manage = new SessionManager();
        if(manage.removeToken(token))
            return true;
        return false;
    }

    @Override
    public JSONObject register(String username, String password,String email){
        User user = userDao.getUserbyUsername(username);
        ErrorMessage errorMessage = new ErrorMessage();
        if(!String.valueOf(user).equals("null")){
            errorMessage.setErrortype(0);
        }
        else{
            User user_1 = userDao.getUserbyEmail(email);
            if(!String.valueOf(user_1).equals("null")){
                errorMessage.setErrortype(1);
            }
            else{
                User create_user = new User();
                create_user.setUsername(username);
                create_user.setPassword(password);
                create_user.setEmail(email);
                create_user.setIsAdmin(false);
                create_user.setIsBan(false);
                userDao.saveOneNotFlush(create_user);
                SuccessMessage successMessage = new SuccessMessage();
                successMessage.setSuccesstype(0);
                return successMessage.getMessage();
            }
        }
        return errorMessage.getMessage();
    }

    @Override
    public JSONObject ban(long admin_token,String target_username){
        SessionManager manage = new SessionManager();
        int userId = manage.getuserId(admin_token);
        ErrorMessage errorMessage = new ErrorMessage();
        SuccessMessage successMessage = new SuccessMessage();
        if(userId == -1){
            errorMessage.setErrortype(2);
            return errorMessage.getMessage();
        }
        User user_admin = userDao.findOne(userId);
        User user_target = userDao.getUserbyUsername(target_username);
        if(String.valueOf(user_admin).equals("null") || String.valueOf(user_target).equals("null")){
            errorMessage.setErrortype(4);
            return errorMessage.getMessage();
        }
        if(user_target.getIsAdmin() || !user_admin.getIsAdmin()){
            errorMessage.setErrortype(3);
            return errorMessage.getMessage();
        }
        long delete_token = manage.getToken(user_target.getUserId());
        manage.removeToken(delete_token);
        user_target.setIsBan(true);
        userDao.saveOne(user_target);
        successMessage.setSuccesstype(1);
        return successMessage.getMessage();
    }

    @Override
    public JSONObject enable(long admin_token,String target_username){
        SessionManager manage = new SessionManager();
        int userId = manage.getuserId(admin_token);
        ErrorMessage errorMessage = new ErrorMessage();
        SuccessMessage successMessage = new SuccessMessage();
        if(userId == -1){
            errorMessage.setErrortype(2);
            return errorMessage.getMessage();
        }
        User user_admin = userDao.findOne(userId);
        User user_target = userDao.getUserbyUsername(target_username);
        if(String.valueOf(user_admin).equals("null") || String.valueOf(user_target).equals("null")){
            errorMessage.setErrortype(4);
            return errorMessage.getMessage();
        }
        if(user_target.getIsAdmin() || !user_admin.getIsAdmin()){
            errorMessage.setErrortype(3);
            return errorMessage.getMessage();
        }
        user_target.setIsBan(false);
        userDao.saveOne(user_target);
        successMessage.setSuccesstype(2);
        return successMessage.getMessage();
    }
}
