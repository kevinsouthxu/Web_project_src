package spring.demo.serviceimpl;
import spring.demo.dao.UserDao;
import spring.demo.service.UserService;
import spring.demo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import spring.demo.SessionManage.SessionManager;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserDao userDao;

    @Override
    public User findUserById(Integer id){
        return userDao.findOne(id);
    }

    @Override
    public User checkUser(String username, String password){
        User user = userDao.checkUser(username,password);
        System.out.println(String.valueOf(user));
        return user;
    }

    @Override
    public User checkUserBytoken(long token){
        SessionManager manage = new SessionManager();
        int userid = manage.getuserId(token);
        User user = userDao.findOne(userid);
        return user;
    }

    @Override
    public long login(String username, String password){
        SessionManager manage = new SessionManager();
        User user = userDao.checkUser(username,password);
        String userString = String.valueOf(user);
        if(userString != "null")
        {
            if(manage.setToken(user.getUserId()))
            {
                long token = manage.getToken(user.getUserId());
                return token;
            }
            else
            {
                long token = manage.getToken(user.getUserId());
                return token;
            }
        }
        return -1;
    }

    @Override
    public boolean logout(long token){
        SessionManager manage = new SessionManager();
        if(manage.removeToken(token))
            return true;
        return false;
    }
}
