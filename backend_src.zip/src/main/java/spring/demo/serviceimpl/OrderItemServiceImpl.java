package spring.demo.serviceimpl;

import spring.demo.dao.OrderItemDao;
import spring.demo.entity.OrderItem;
import spring.demo.service.OrderItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderItemServiceImpl implements OrderItemService{
    @Autowired
    private OrderItemDao orderItemDao;

    @Override
    public OrderItem findOrderItemById(Integer id){
        return orderItemDao.findOne(id);
    }
}
