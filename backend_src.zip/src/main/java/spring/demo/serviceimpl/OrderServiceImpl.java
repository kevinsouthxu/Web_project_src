package spring.demo.serviceimpl;

import spring.demo.SessionManage.SessionManager;
import spring.demo.dao.*;
import spring.demo.entity.*;
import spring.demo.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService{
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private OrderItemDao orderItemDao;
    @Autowired
    private BookDao bookDao;

    @Override
    public Order findOrderById(Integer id){
        return orderDao.findOne(id);
    }

    @Override
    public boolean addOrder(int userId, List<Integer> cart, List<Integer> cart_count) {
        User user = userDao.findOne(userId);
        List<OrderItem> orderItemList = new ArrayList<>();
        int amount = 0;
        int price = 0;
        List<Book> bookList = new ArrayList<>();
        for(int i = 0;i < cart.size();i++)
        {

            OrderItem orderItem = new OrderItem();
            orderItem.setBook_id(cart.get(i));
            orderItem.setAmount(cart_count.get(i));

            Book b = bookDao.findOne(cart.get(i));
            if((b.getRepertory() - cart_count.get(i)) < 0)
                return false;
            int repe = b.getRepertory() -cart_count.get(i);
            b.setRepertory(repe);
            bookList.add(b);
            amount += cart_count.get(i);
            price += Integer.parseInt(b.getPrice().substring(1)) * cart_count.get(i);
            orderItemList.add(orderItem);
        }
        for(int i = 0; i < orderItemList.size() ;i++)
        {
            orderItemDao.saveOne(orderItemList.get(i));
            bookDao.saveOne(bookList.get(i));
        }
        Order order = new Order();
        order.setOrder(orderItemList);
        order.setTotal_amount(amount);
        order.setTotal_price(price);
        orderDao.saveOne(order);
        List<Order> orderList;
        if(user.getOrder() != null && user.getOrder().size() > 0)
        {
            orderList = user.getOrder();
            orderList.add(order);
            user.setOrder(orderList);
        }
        else
        {
            orderList = new ArrayList<>();
            orderList.add(order);
            user.setOrder(orderList);
        }
        userDao.saveOne(user);
        return true;
    }

    @Override
    public boolean addOrderBytoken(long token, List<Integer> cart, List<Integer> cart_count) {
        SessionManager manage = new SessionManager();
        int userId = manage.getuserId(token);
        User user = userDao.findOne(userId);
        List<OrderItem> orderItemList = new ArrayList<>();
        int amount = 0;
        int price = 0;
        List<Book> bookList = new ArrayList<>();
        for(int i = 0;i < cart.size();i++)
        {

            OrderItem orderItem = new OrderItem();
            orderItem.setBook_id(cart.get(i));
            orderItem.setAmount(cart_count.get(i));

            Book b = bookDao.findOne(cart.get(i));
            if((b.getRepertory() - cart_count.get(i)) < 0)
                return false;
            int repe = b.getRepertory() -cart_count.get(i);
            b.setRepertory(repe);
            bookList.add(b);
            amount += cart_count.get(i);
            price += Integer.parseInt(b.getPrice().substring(1)) * cart_count.get(i);
            orderItemList.add(orderItem);
        }
        for(int i = 0; i < orderItemList.size() ;i++)
        {
            orderItemDao.saveOne(orderItemList.get(i));
            bookDao.saveOne(bookList.get(i));
        }
        Order order = new Order();
        order.setOrder(orderItemList);
        order.setTotal_amount(amount);
        order.setTotal_price(price);
        orderDao.saveOne(order);
        List<Order> orderList;
        if(user.getOrder() != null && user.getOrder().size() > 0)
        {
            orderList = user.getOrder();
            orderList.add(order);
            user.setOrder(orderList);
        }
        else
        {
            orderList = new ArrayList<>();
            orderList.add(order);
            user.setOrder(orderList);
        }
        userDao.saveOne(user);
        return true;
    }

    @Override
    public boolean deleteOrder(int userId,int orderId){
        User user = userDao.findOne(userId);
        List<Order> orderList = user.getOrder();
        Order order = null;
        for(int i = 0;i < orderList.size();i++) {
            if(orderList.get(i).getOrderId() == orderId)
            {
                order = orderList.remove(i);
                break;
            }
        }
        if(order == null)
            return false;
        user.setOrder(orderList);
        List<OrderItem> oldList = order.getOrder();

        List<Book> bookList = new ArrayList<>();
        List<Integer> count = new ArrayList<>();
        for(int i = 0;i < oldList.size();i++)
        {
            OrderItem orderItem = orderItemDao.findOne(oldList.get(i).getOrderItemId());
            count.add(orderItem.getAmount());
            bookList.add(bookDao.findOne(orderItem.getBook_id()));
        }
        System.out.println(oldList.size());
        List<OrderItem> newList = new ArrayList<>();
        order.setOrder(newList);
        orderDao.saveOne(order);
        for(int i = 0;i < oldList.size();i++)
        {
            orderItemDao.deleteOneById(oldList.get(i).getOrderItemId());
        }
        orderDao.deleteOne(order);
        for(int i = 0;i < bookList.size();i++)
        {
            Book b = bookList.get(i);
            int amount = b.getRepertory() + count.get(i);
            b.setRepertory(amount);
            bookDao.saveOne(b);
        }
        return true;
    }

    @Override
    public boolean deleteOrderBytoken(long token,int orderId){
        SessionManager manage = new SessionManager();
        int userId = manage.getuserId(token);
        User user = userDao.findOne(userId);
        List<Order> orderList = user.getOrder();
        Order order = null;
        for(int i = 0;i < orderList.size();i++) {
            if(orderList.get(i).getOrderId() == orderId)
            {
                order = orderList.remove(i);
                break;
            }
        }
        if(order == null)
            return false;
        user.setOrder(orderList);
        List<OrderItem> oldList = order.getOrder();

        List<Book> bookList = new ArrayList<>();
        List<Integer> count = new ArrayList<>();
        for(int i = 0;i < oldList.size();i++)
        {
            OrderItem orderItem = orderItemDao.findOne(oldList.get(i).getOrderItemId());
            count.add(orderItem.getAmount());
            bookList.add(bookDao.findOne(orderItem.getBook_id()));
        }
        System.out.println(oldList.size());
        List<OrderItem> newList = new ArrayList<>();
        order.setOrder(newList);
        orderDao.saveOne(order);
        for(int i = 0;i < oldList.size();i++)
        {
            orderItemDao.deleteOneById(oldList.get(i).getOrderItemId());
        }
        orderDao.deleteOne(order);
        for(int i = 0;i < bookList.size();i++)
        {
            Book b = bookList.get(i);
            int amount = b.getRepertory() + count.get(i);
            b.setRepertory(amount);
            bookDao.saveOne(b);
        }
        return true;
    }

    @Override
    public List<Order> findOrderBytoken(long token)
    {
        SessionManager manage = new SessionManager();
        int userId = manage.getuserId(token);
        User user = userDao.findOne(userId);
        List<Order> orderList = user.getOrder();
        return orderList;
    }
}
