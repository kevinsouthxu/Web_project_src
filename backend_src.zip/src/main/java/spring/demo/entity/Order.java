package spring.demo.entity;
import com.fasterxml.jackson.annotation.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Table(name="orders",schema="backend")
@JsonIgnoreProperties(value = {"handler","hibernateLazyInitializer","fieldHandler"})
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "orderId")
public class Order {
    private int orderId;
    private int total_price;
    private int total_amount;
    private List<OrderItem> orderitems = new ArrayList<OrderItem>();

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = IDENTITY)
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    @Basic
    @Column(name = "total_price")
    public int getTotal_price() {
        return total_price;
    }

    public void setTotal_price(int total_price) {
        this.total_price = total_price;
    }
    @Basic
    @Column(name = "total_amount")
    public int getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(int total_amount) {
        this.total_amount = total_amount;
    }

    @OneToMany(fetch = FetchType.LAZY)
    @JoinTable(name="order_items",joinColumns = @JoinColumn(name = "order_id"),
            inverseJoinColumns = @JoinColumn(name = "items_id"))
    public List<OrderItem> getOrder() {
        return orderitems;
    }

    public void setOrder(List<OrderItem> orderitems) {
        this.orderitems = orderitems;
    }
}
