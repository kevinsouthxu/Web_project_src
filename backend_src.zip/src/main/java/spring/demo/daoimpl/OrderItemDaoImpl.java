package spring.demo.daoimpl;

import spring.demo.dao.OrderItemDao;
import spring.demo.entity.OrderItem;
import spring.demo.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class OrderItemDaoImpl implements  OrderItemDao{
    @Autowired
    private OrderItemRepository orderItemRepository;

    @Override
    public OrderItem findOne(Integer id) {   return orderItemRepository.getOne(id);}

    @Override
    public void saveOne(OrderItem item)
    {
        orderItemRepository.saveAndFlush(item);
    }
    @Override
    public void deleteOne(OrderItem item)
    {
        orderItemRepository.delete(item);
    }
    @Override
    public void deleteOneById(int id)
    {
        orderItemRepository.deleteById(id);
    }
}
