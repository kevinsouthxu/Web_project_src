package spring.demo.daoimpl;

import spring.demo.dao.BookDao;
import spring.demo.entity.Book;
import spring.demo.entity.BookImage;
import spring.demo.repository.BookRepository;
import spring.demo.repository.BookImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class BookDaoImpl implements  BookDao{
    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private BookImageRepository bookImageRepository;

    @Override
    public List<Book> getBooks(){
        List<Book> bookList = bookRepository.getBooks();
        for(int i = 0;i < bookList.size();i++) {
            Optional<BookImage> image = bookImageRepository.findById(bookList.get(i).getBookId());
            if (image.isPresent()){
                bookList.get(i).setImage(image.get());
            }
            else{
                bookList.get(i).setImage(null);
                System.out.println("It's Null");
            }
        }
        return bookRepository.getBooks();
    }

    @Override
    public Book findOne(Integer id) {
        Book book = bookRepository.getOne(id);
        Optional<BookImage> image = bookImageRepository.findById(id);
        if (image.isPresent()){
            System.out.println("Not Null " + id);
            book.setImage(image.get());
        }
        else{
            book.setImage(null);
            System.out.println("It's Null");
        }
        return book;
    }
    @Override
    public void saveOne(Book b){
        bookRepository.saveAndFlush(b);
    }
    @Override
    public Boolean changeImage(Integer id,String base64){
        Optional<BookImage> image = bookImageRepository.findById(id);
        if (image.isPresent()){
            BookImage bookImage = image.get();
            bookImage.setBase64(base64);
            bookImageRepository.save(bookImage);
            return true;
        }
        else{
            BookImage bookImage = new BookImage(id,base64);
            bookImageRepository.save(bookImage);
            return true;
        }
    }
}
