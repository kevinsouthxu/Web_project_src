package spring.demo.daoimpl;

import spring.demo.dao.OrderDao;
import spring.demo.entity.Order;
import spring.demo.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class OrderDaoImpl implements  OrderDao{
    @Autowired
    private OrderRepository orderRepository;

    @Override
    public Order findOne(Integer id) {   return orderRepository.getOne(id);}

    @Override
    public List<Order> getOrders() { return orderRepository.getOrders(); }

    @Override
    public void saveOne(Order item)
    {
        orderRepository.saveAndFlush(item);
    }

    @Override
    public void deleteOne(Order item){  orderRepository.delete(item);}
}
