package spring.demo.daoimpl;

import spring.demo.dao.UserDao;
import spring.demo.entity.OrderItem;
import spring.demo.entity.User;
import spring.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements  UserDao{
    @Autowired
    private UserRepository userRepository;

    @Override
    public User findOne(Integer id) {   return userRepository.getOne(id);}

    @Override
    public User checkUser(String username, String password){
        return userRepository.checkUser(username,password);
    }

    @Override
    public void saveOne(User user)
    {
        userRepository.saveAndFlush(user);
    }
}
