package spring.demo.controller;

import spring.demo.entity.OrderItem;
import spring.demo.service.OrderItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class OrderItemController {
    @Autowired
    private OrderItemService orderItemService;

    @GetMapping(value = "/findOrderItem/{id}")
    public OrderItem findOrderItem(@PathVariable("id") Integer id) {
        System.out.println("Searching OrderItem: " + id);
        return orderItemService.findOrderItemById(id);
    }
}
