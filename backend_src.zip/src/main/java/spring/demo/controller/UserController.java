package spring.demo.controller;

import spring.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import spring.demo.entity.User;

@CrossOrigin
@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping(value = "/findUser/{id}")
    public User findUser(@PathVariable("id") Integer id) {
        System.out.println("Searching User: " + id);
        return userService.findUserById(id);
    }
    @RequestMapping("/checkUser")
    public User checkUser(@RequestParam("username") String username,@RequestParam("password") String password){
        System.out.println("Searching User: " + userService.checkUser(username, password).getUsername());
        return userService.checkUser(username, password);
    }
    @RequestMapping("/checkUserBytoken")
    public User checkUserBytoken(@RequestParam("token") long token) {
        return userService.checkUserBytoken(token);
    }
    @RequestMapping("/login")
    public long login(@RequestParam("username") String username,@RequestParam("password") String password) {
        System.out.println("login " + username);
        return userService.login(username,password);
    }
    @RequestMapping("/logout")
    public boolean logout(@RequestParam("token") long token){
        return userService.logout(token);
    }
}
