package spring.demo.controller;

import net.minidev.json.JSONObject;
import spring.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import spring.demo.entity.User;

@CrossOrigin
@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping(value = "/findUser/{id}")
    public User findUser(@PathVariable("id") Integer id) {
        System.out.println("Searching User: " + id);
        return userService.findUserById(id);
    }
    @RequestMapping("/checkUser")
    public User checkUser(@RequestParam("username") String username,@RequestParam("password") String password){
        System.out.println("Searching User: " + userService.checkUser(username, password).getUsername());
        return userService.checkUser(username, password);
    }
    @RequestMapping("/checkUserBytoken")
    public User checkUserBytoken(@RequestParam("token") long token) {
        return userService.checkUserBytoken(token);
    }
    @RequestMapping("/login")
    public long login(@RequestParam("username") String username,@RequestParam("password") String password) {
        System.out.println("login " + username);
        return userService.login(username,password);
    }
    @RequestMapping("/logout")
    public boolean logout(@RequestParam("token") long token){
        return userService.logout(token);
    }
    @RequestMapping("/register")
    public JSONObject register(@RequestParam("username") String username, @RequestParam("password") String password,@RequestParam("email") String email){
        return userService.register(username, password,email);
    }
    @RequestMapping("/ban")
    public JSONObject ban(@RequestParam("admin_token") long token, @RequestParam("target_username") String username){
        return userService.ban(token,username);
    }
    @RequestMapping("/enable")
    public JSONObject enable(@RequestParam("admin_token") long token, @RequestParam("target_username") String username){
        return userService.enable(token,username);
    }
}
