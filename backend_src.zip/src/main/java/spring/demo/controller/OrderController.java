package spring.demo.controller;

import org.springframework.web.bind.annotation.*;
import spring.demo.entity.Order;
import spring.demo.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
@CrossOrigin
@RestController
public class OrderController {
    @Autowired
    private OrderService orderService;

    @GetMapping(value = "/findOrder/{id}")
    public Order findOrder(@PathVariable("id") Integer id) {
        System.out.println("Searching Order: " + id);
        return orderService.findOrderById(id);
    }
    @RequestMapping("/addOrder")
    public boolean addOrder(@RequestParam("userId") int userId,
                            @RequestParam("cart") List<Integer> cart,
                            @RequestParam("cart_count") List<Integer> cart_count){
        return orderService.addOrder(userId,cart,cart_count);
    }
    @RequestMapping("/addOrderBytoken")
    public boolean addOrderBytoken(@RequestParam("token") long token,
                            @RequestParam("cart") List<Integer> cart,
                            @RequestParam("cart_count") List<Integer> cart_count){
        return orderService.addOrderBytoken(token,cart,cart_count);
    }
    @RequestMapping("/findOrderBytoken")
    public List<Order> findOrderBytoken(@RequestParam("token") long token){
        return orderService.findOrderBytoken(token);
    }
    @RequestMapping("/deleteOrder")
    public boolean deleteOrder(@RequestParam("userId") int userId,@RequestParam("orderId") int orderId) {
        return orderService.deleteOrder(userId,orderId);
    }
    @RequestMapping("/deleteOrderBytoken")
    public boolean deleteOrderBytoken(@RequestParam("token") long token,@RequestParam("orderId") int orderId) {
        return orderService.deleteOrderBytoken(token,orderId);
    }
}
