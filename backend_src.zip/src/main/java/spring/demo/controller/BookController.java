package spring.demo.controller;

import net.minidev.json.JSONObject;
import org.springframework.web.bind.annotation.*;
import spring.demo.entity.Book;
import spring.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
@CrossOrigin
@RestController
public class BookController {
    @Autowired
    private BookService bookService;

    @GetMapping(value = "/findBook/{id}")
    public Book findBook(@PathVariable("id") Integer id) {
        System.out.println("Searching Book: " + id);
        return bookService.findBookById(id);
    }
    @RequestMapping("/findBooks")
    public List<Book> findBooks(@RequestParam("books") List<Integer> books)
    { return bookService.findBooks(books);}

    @GetMapping("/getBooks")
    public List<Book> getBooks() {return bookService.getBooks();}

    @RequestMapping("/changeBook")
    public JSONObject changeBook(@RequestBody Map<String, String> map){
        return bookService.changeBook(map);
    }
}
