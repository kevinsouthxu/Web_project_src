package spring.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import spring.demo.service.CartService;

import java.util.List;

@CrossOrigin
@RestController
public class CartController {
    @Autowired
    private CartService cartService;

    @RequestMapping("/addCart")
    public boolean addCart(@RequestParam("token") long token,
                            @RequestParam("bookId") int bookId){
        return cartService.addCart(token,bookId);
    }

    @RequestMapping("/deleteCart")
    public boolean deleteCart(@RequestParam("token") long token,
                           @RequestParam("bookId") int bookId){
        return cartService.deleteCart(token,bookId);
    }

    @RequestMapping("/increaseCart")
    public boolean increaseCart(@RequestParam("token") long token,
                                @RequestParam("bookId") int bookId,
                                @RequestParam("num") int num){
        return cartService.increaseCart(token,bookId,num);
    }

    @RequestMapping("/decreaseCart")
    public boolean decreaseCart(@RequestParam("token") long token,
                                @RequestParam("bookId") int bookId,
                                @RequestParam("num") int num){
        return cartService.decreaseCart(token,bookId,num);
    }

    @RequestMapping("/getCart")
    public List getCart(@RequestParam("token") long token){
        return cartService.getCart(token);
    }
}
