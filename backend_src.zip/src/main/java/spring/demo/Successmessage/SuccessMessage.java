package spring.demo.Successmessage;

import net.minidev.json.JSONObject;

public class SuccessMessage {
        private int successtype;
        private String successmessage;
        private void setSuccessmessage(String success){
            this.successmessage = success;
        }
        public String getSuccessmessage(){
            return successmessage;
        }
        public void setSuccesstype(int type){
            this.successtype = type;
            switch(type){
                case 0:{
                    this.setSuccessmessage("Success 0: register is success");
                    break;
                }
                case 1:{
                    this.setSuccessmessage("Success 1: ban operation is success");
                    break;
                }
                case 2:{
                    this.setSuccessmessage("Success 2: enable operation is success");
                    break;
                }
                case 3:{
                    this.setSuccessmessage("Success 3: succesfully change book");
                    break;
                }
                default:
            }
        }
        public JSONObject getMessage(){
            JSONObject object = new JSONObject();
            object.put("SuccessType",successtype);
            object.put("SuccessMessage",successmessage);
            return object;
        }

}
