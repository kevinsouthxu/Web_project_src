package spring.demo.service;
import spring.demo.SessionManage.cart;

import java.util.List;

public interface CartService {
    boolean addCart(long token,int bookId);
    boolean deleteCart(long token,int bookId);
    boolean increaseCart(long token,int bookId,int num);
    boolean decreaseCart(long token,int bookId,int num);
    List getCart(long token);
}
