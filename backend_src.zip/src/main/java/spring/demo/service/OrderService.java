package spring.demo.service;

import org.springframework.web.bind.annotation.RequestParam;
import spring.demo.entity.Order;

import java.util.List;

public interface OrderService {
    Order findOrderById(Integer id);
    boolean addOrder(int userId, List<Integer> cart,List<Integer> cart_count);
    boolean deleteOrder(int userId,int orderId);
    boolean addOrderBytoken(long token,List<Integer> cart,List<Integer> cart_count);
    boolean deleteOrderBytoken(long token,int orderId);
    List<Order> findOrderBytoken(long token);
}
