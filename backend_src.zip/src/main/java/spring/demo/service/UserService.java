package spring.demo.service;

import net.minidev.json.JSONObject;
import spring.demo.entity.User;
public interface UserService {
    User findUserById(Integer id);
    User checkUser(String username, String password);
    User checkUserBytoken(long token);
    long login(String username, String password);
    boolean logout(long token);
    JSONObject register(String username, String password,String email);
    JSONObject ban(long admin_token,String target_username);
    JSONObject enable(long admin_token,String target_username);
}
