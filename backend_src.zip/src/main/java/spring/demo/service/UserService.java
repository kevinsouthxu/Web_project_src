package spring.demo.service;

import spring.demo.entity.User;
public interface UserService {
    User findUserById(Integer id);
    User checkUser(String username, String password);
    User checkUserBytoken(long token);
    long login(String username, String password);
    boolean logout(long token);
}
