package spring.demo.service;

import spring.demo.entity.OrderItem;

public interface OrderItemService {
    OrderItem findOrderItemById(Integer id);
}
