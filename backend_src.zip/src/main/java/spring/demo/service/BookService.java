package spring.demo.service;

import net.minidev.json.JSONObject;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import spring.demo.entity.Book;
import java.util.List;
import java.util.Map;
public interface BookService {
    Book findBookById(Integer id);

    List<Book> getBooks();

    List<Book> findBooks(List<Integer> books);

    JSONObject changeBook(Map<String, String> map);

    JSONObject createBook(Map<String, String> map);
}
