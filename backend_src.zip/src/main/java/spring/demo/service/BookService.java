package spring.demo.service;

import spring.demo.entity.Book;
import java.util.List;
public interface BookService {
    Book findBookById(Integer id);

    List<Book> getBooks();

    List<Book> findBooks(List<Integer> books);
}
