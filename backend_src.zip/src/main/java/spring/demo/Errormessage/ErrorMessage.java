package spring.demo.Errormessage;

import net.minidev.json.JSONObject;

public class ErrorMessage {
    private int errortype;
    private String errormessage;
    private void setErrormessage(String error){
        this.errormessage = error;
    }
    public String getErrormessage(){
        return errormessage;
    }
    public void setErrortype(int type){
        this.errortype = type;
        switch(type){
            case 0:{
                this.setErrormessage("Error 0: username exists already");
                break;
            }
            case 1:{
                this.setErrormessage("Error 1: email has been registered");
                break;
            }
            case 2:{
                this.setErrormessage("Error 2: token is unvalid");
                break;
            }
            case 3:{
                this.setErrormessage("Error 3: you do not have this right");
                break;
            }
            case 4:{
                this.setErrormessage("Error 4: user do not exists");
                break;
            }
            case 5:{
                this.setErrormessage("Error 5: book do not exists");
                break;
            }
            case 6:{
                this.setErrormessage("Error 6: need bookId");
                break;
            }
            case 7:{
                this.setErrormessage("Error 7: need user_token");
                break;
            }
            default:
        }
    }
    public JSONObject getMessage(){
        JSONObject object = new JSONObject();
        object.put("ErrorType",errortype);
        object.put("ErrorMessage",errormessage);
        return object;
    }

}
