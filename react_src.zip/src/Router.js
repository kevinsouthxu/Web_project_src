import React from 'react';
import { Router, Route, Switch, Redirect} from 'react-router';
import _mainpage from "./view/mainpage";
import _loginpage from "./view/loginpage";
import _managepage from "./view/managepage";
import _cartpage from "./view/cartpage";
import _orderpage from "./view/orderpage";
import _bookinfo from "./view/bookinfo";
import _registerpage from "./view/registerpage";
import {history} from "./utils/history";

let books=[
    // {name:'万历十五年', author:'黄仁宇', ISBN:'978-7-108-00982-1', number:'1', src:'./img/2.png', price:'$45'},
    // {name:'白夜行', author:'东野圭吾', ISBN:'978-7-5442-4251-6', number:'2', src:'./img/3.png', price:'$32'},
    // {name:'非暴力沟通', author:'马歇尔·卢森堡', ISBN:'978-7-5080-5100-0', number:'3', src:'./img/4.png', price:'$40'},
    // {name:'原则', author:'[美]瑞·达利欧', ISBN:'978-7-5086-8403-1', number:'4', src:'./img/5.png', price:'$41'},
    // {name:'人生的智慧', author:'[德]阿图尔·叔本华', ISBN:'978-7-2080-8117-8', number:'5', src:'./img/6.png', price:'$37'},
    // {name:'活着', author:'余华', ISBN:'978-7-5442-1096-6', number:'6', src:'./img/7.png', price:'$32'},
];

class BasicRoute extends React.Component{

    constructor(props) {
        super(props);
        //localStorage.clear();
        history.listen((location, action) => {
            // clear alert on location change
            console.log(location,action);
        });
    }
    getBooks = () =>{
        if(books.length === 0 ) {
            fetch("http://localhost:8080/getBooks")
                .then(response => response.json())
                .then(data => {
                    this.setState({books: data,});
                    books = this.state.books;
                }).catch(function (ex) {
                console.log('parsing failed', ex)
            });
        }
        // console.log(books);
    };


    render(){
        this.getBooks();
        return(
            <Router history={history}>
                <Switch>
                    <Route exact path="/"  >
                        <_mainpage books={books} getBook={this.getBooks}/></Route>
                    <Route exact path="/login"  ><_loginpage /></Route>
                    <Route exact path="/manage"  >
                        <_managepage books={books}/></Route>
                    <Route exact path="/cart" >
                        <_cartpage books={books}/></Route>
                    <Route exact path="/order" >
                        <_orderpage />
                    </Route>
                    <Route exact path="/bookinfo" >
                        <_bookinfo books={books}/>
                    </Route>
                    <Route exact path="/register" >
                        <_registerpage/>
                    </Route>
                    <Redirect from="/*" to="/" />
                </Switch>
            </Router>
        )
    }


}

export default BasicRoute;
