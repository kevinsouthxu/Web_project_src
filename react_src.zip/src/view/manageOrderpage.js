import React from 'react';
import {Col, Layout, Row,Input,DatePicker} from "antd";
import {Redirect} from "react-router";
import _manageheader from "../components/manageheader";
import _side from "../components/menu";
import OrderExcel from "../components/orderExcel";
const { Header, Sider } = Layout;
const { Search } = Input;
const { RangePicker } = DatePicker;
class  _manageOrderpage extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            searchValue:"",
            startDate:0,
            endDate:0
        };

    };
    dateChange = (date,dateString) => {
        if(date===null || dateString===null){
            this.state.startDate = 0;
            this.state.endDate = 0;
            return;
        }
        if(dateString.length===2) {
            this.state.startDate = parseInt(dateString[0].substr(0,4)
                                        +dateString[0].substr(5,2)
                                        +dateString[0].substr(8,2));
            this.state.endDate = parseInt(dateString[1].substr(0,4)
                                        +dateString[1].substr(5,2)
                                        +dateString[1].substr(8,2));
        }
    };
    search = value =>{
        this.setState({searchValue:value});
    };
    render() {
        return (
            <div>
                {sessionStorage.length ===0 ?<Redirect to="/login"/>:(
                    <Layout className="full-height">
                        <Header className="header">
                            <_manageheader />
                        </Header>
                        <Layout >
                            <Sider width={200} className="site-layout-background">
                                <_side switchKey='6'/>
                            </Sider>
                            <Layout style={{padding: '0 5% 5%'}}>
                                <br/>
                                <Row>
                                    <Col span={6}>
                                        <RangePicker onChange={this.dateChange} size='large'/>
                                    </Col>
                                    <Col span={4}></Col>
                                    <Col span={14}>
                                        <Search
                                            placeholder="输入书名搜索"
                                            enterButton="搜索"
                                            size="large"
                                            onSearch={value => this.search(value)}
                                        />
                                    </Col>
                                </Row>
                                <br/>
                                <OrderExcel filterText = {this.state.searchValue}
                                            startDate = {this.state.startDate}
                                            endDate = {this.state.endDate}
                                            onSearch={this.search}/>
                            </Layout>

                        </Layout>
                    </Layout>
                )}
            </div>
        );
    }
}
export default  _manageOrderpage;
