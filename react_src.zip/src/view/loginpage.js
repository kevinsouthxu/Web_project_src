import React from 'react';
import LoginForm from '../components/Login_input';
import {withRouter} from "react-router-dom";
import { CreditCardOutlined,ToolOutlined,TeamOutlined    } from '@ant-design/icons';
import _manageheader from "../components/manageheader";
import {Layout,Card, Col, Row,Button} from "antd";
import _side from "../components/menu";
import * as userService from '../service/UserService';
let user = {};
const { Header, Sider } = Layout;
class LoginView extends React.Component{
    constructor(props) {
        super(props);
        user = JSON.parse(sessionStorage.getItem("user"));
    };
    logout = () =>{
        let data = {
          token:sessionStorage.getItem('userToken')
        };
        userService.logout(data);
    };
    render(){
        return(
            <div>
                {sessionStorage.length ===0 ? (
                    <div className="login-page">
                        <div className="login-container">
                            <div className="login-box">
                                <h1 className="page-title">登录</h1>
                                <div className="login-content">
                                    <LoginForm />
                                </div>
                            </div>
                        </div>
                    </div>
                ) :(
                    <div>
                            <Layout className="full-height">
                                <Header className="header">
                                    <_manageheader />
                                </Header>
                                <Layout >
                                    <Sider width={200} className="site-layout-background">
                                        <_side />
                                    </Sider>
                                    <Layout style={{padding: '0 5% 5%'}}>
                                        <br/><br/>
                                        <Row gutter={16}>
                                            <Col span={8}>
                                                <Card title="用户信息" style={{borderRadius:"30px"}}>
                                                    <p>姓：{user.lastname}</p>
                                                    <p>名：{user.firstname}</p>
                                                    <p>年龄：{user.age}</p>
                                                    <Button type="link" block onClick={this.logout}>
                                                        登出
                                                    </Button>
                                                </Card>
                                            </Col>
                                            <Col span={8}>
                                                <Card title="其他功能" style={{borderRadius:"30px"}}>
                                                    <Button block type={"link"}><CreditCardOutlined />
                                                    余额管理</Button>
                                                    <br/><br/>
                                                    <Button block type={"link"}><ToolOutlined />
                                                    账号设置</Button>
                                                    <br/><br/>
                                                    <Button block type={"link"}><TeamOutlined />
                                                    好友相关</Button>

                                                </Card>
                                            </Col>
                                            <Col span={8}>
                                                <Card title="待扩展卡片" style={{borderRadius:"30px"}}>
                                                    待扩展内容
                                                </Card>
                                            </Col>
                                        </Row>
                                    </Layout>
                                </Layout>
                            </Layout>
                    </div>
                )
                }
            </div>
        );

    }
}

export default withRouter(LoginView);
