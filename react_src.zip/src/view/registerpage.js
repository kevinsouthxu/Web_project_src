import React from 'react';
import RegisterForm from "../components/Register_input";

class  _registerpage extends React.Component{
    render() {
        return (
            <div>
                <div className="register-page">
                    <div className="login-container">
                        <div className="login-box">
                            <h1 className="page-title">注册账号</h1>
                            <div className="login-content">
                                <RegisterForm/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default  _registerpage;
