import {Layout, List, Table, Row, Spin, Col, Card, Button, message,Input,DatePicker} from 'antd';
import 'antd/dist/antd.css';
import React from 'react';
import _manageheader from "../components/manageheader";
import _side from '../components/menu';
import '../lib/style1.css';
import '../lib/bootstrap.min.css';
import {Redirect} from "react-router";
import {postRequest} from "../utils/ajax";
import {CloseOutlined } from "@ant-design/icons";
import * as orderService from '../service/OrderService';
const { Header, Sider } = Layout;
const { Search } = Input;
const { RangePicker } = DatePicker;

const data = [];
const columns = [
    {
        title: '图片',
        dataIndex: 'src',
        key: 'src',
    },
    {
        title: '书名',
        dataIndex: 'name',
        key: 'name',
    },
    {
        title: '个数',
        dataIndex: 'amount',
        key: 'amount',
    },
    {
        title: '价钱',
        dataIndex: 'price',
        key: 'price',
    },
];
class  _orderpage extends React.Component{
    constructor(props) {
        super(props);
        this.initial();
        this.state = {
            originData:[],
            startDate:"",
            endDate:""
        };
    };

    initial = () =>{
        data.splice(0,data.length);
        // let user_json = JSON.parse(sessionStorage.getItem('user'));
        let send_data = {
            token: sessionStorage.getItem('userToken')
        };
        const callback = back_data => {
            let order = back_data;
            for(let i = 0;i < order.length;i ++)
            {
                data.push({
                    orderId:order[i].orderId,
                    total_price:order[i].total_price,
                    amount:order[i].total_amount,
                    date:order[i].date,
                    orderItems:[],
                });
                this.findBooks(i,order[i].order);
            }
            for(let i = 0;i <data.length;i++){
                this.state.originData.push(data[i]);
            }


        }
        orderService.findOrder(send_data,callback);
    };

    deleteOrder = orderid =>{
        let usertoken = JSON.parse(sessionStorage.getItem('userToken'));
        let thedata = {
            token:usertoken,
            orderId:orderid
        }
        const callback = (back_data) =>{
            console.log("ok");
            for(let i = 0;i < data.length;i++)
            {
                if(data[i].orderId === orderid)
                    data.splice(i,1);
            }
            for(let i = 0;i < this.state.originData.length;i++)
            {
                if(this.state.originData[i].orderId === orderid)
                    this.state.originData.splice(i,1);
            }
            if(back_data === true)
                message.success('删除订单成功');
            else
                message.error('删除订单失败');
            this.setState({});
        }
        orderService.deleteOrder(thedata,callback);
    }

    findBooks = (index,orderarray) => {
        const url = `http://localhost:8080/findBooks`;
        const callback = (book_data) =>{
            for(let i = 0; i < book_data.length;i++)
            {
                data[index].orderItems.push({
                    "bookId": book_data[i].bookId,
                    "src": <img src={book_data[i].image.base64} alt ={book_data[i].src} style={{width:'20%'}}></img>,
                    "name": book_data[i].name,
                    "amount": orderarray[i].amount,
                    "price": orderarray[i].amount * parseInt(book_data[i].price.substr(1))
                });
            }
            this.setState({});
        };
        let array = [];
        for(let i = 0;i < orderarray.length;i++) {
            array.push(orderarray[i].book_id);
        }
        let book_data = {
            books:array
        };
        postRequest(url,book_data,callback);
    };

    search = value =>{
        data.splice(0,data.length);
        for(let i = 0;i < this.state.originData.length;i ++)
        {
            for(let j = 0;j < this.state.originData[i].orderItems.length;j++){
                if(this.state.originData[i].orderItems[j].name.indexOf(value)!==-1){
                    data.push(this.state.originData[i]);
                    break;
                }
            }
        }
        console.log(this.state);
        if(this.state.startDate!=="" && this.state.endDate!==""){
            let tempData = [];
            for(let i = 0;i <data.length;i++){
                tempData.push(data[i]);
            }
            data.splice(0,data.length);
            let startDate = parseInt(this.state.startDate.substr(0,4)
                                       +this.state.startDate.substr(5,2)
                                       +this.state.startDate.substr(8,2));
            let endDate = parseInt(this.state.endDate.substr(0,4)
                                     +this.state.endDate.substr(5,2)
                                     +this.state.endDate.substr(8,2));
            for(let i = 0;i <tempData.length;i++){
                let currentDate = parseInt(tempData[i].date.substr(0,4)
                                             +tempData[i].date.substr(5,2)
                                             +tempData[i].date.substr(8,2));
                if(currentDate >= startDate && currentDate <= endDate){
                    data.push(tempData[i]);
                }
            }
        }
        this.setState({});
    };

    dataChange = (date,dateString) => {
        if(date===null || dateString===null){
            this.state.startDate = "";
            this.state.endDate = "";
            return;
        }
        if(dateString.length===2)
            this.state.startDate = dateString[0];
            this.state.endDate = dateString[1];
    };
    render() {
        return (
            <div>
                {sessionStorage.length ===0 ?<Redirect to="/login"/>:(
                    <Layout className="full-height">
                        <Header className="header">
                            <_manageheader />
                        </Header>
                        <Layout >
                            <Sider width={200} className="site-layout-background">
                                <_side switchKey='3'/>
                            </Sider>
                            <Layout style={{padding: '0 5% 5%'}}>
                                <br/>
                                <Row>
                                    <Col span={6}>
                                    <RangePicker onChange={this.dataChange} size='large'/>
                                    </Col>
                                    <Col span={4}></Col>
                                    <Col span={14}>
                                    <Search
                                        placeholder="输入书名搜索"
                                        enterButton="搜索"
                                        size="large"
                                        onSearch={value => this.search(value)}
                                    />
                                    </Col>
                                </Row>
                                <br/>
                                <List
                                    itemLayout="horizontal"
                                    dataSource={data}
                                    title="已下订单"
                                    renderItem={item => (
                                        <List.Item  key={item}>
                                            <Row style={{width:'100%'}} key="row1">
                                                {item.orderItems.length === 0? <Spin/>:
                                                    <Row style={{width:'100%'}} key="row2">
                                                        <Col span={13} key="col1">
                                                            <Table dataSource={item.orderItems} columns={columns} />
                                                        </Col>
                                                        <Col span={5} key="col2"></Col>
                                                        <Col span = {6} key="col3">
                                                            <Card size="small" title="订单信息" extra={<a href="#">更多</a>} style={{ width: 300 }}>
                                                                <p>购买书本总个数：{item.amount}</p>
                                                                <p>购买书本总金额：{item.total_price}</p>
                                                                <p>下单日期：{item.date}</p>
                                                                <Button shape="round" size="default" onClick={()=>this.deleteOrder(item.orderId)}><CloseOutlined />删除订单</Button>
                                                            </Card>
                                                        </Col>
                                                    </Row>
                                                }
                                            </Row>
                                        </List.Item>
                                    )}
                                />
                            </Layout>

                        </Layout>
                    </Layout>
                )}
            </div>
        );
    }
}
export default  _orderpage;
