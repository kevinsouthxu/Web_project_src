import React from 'react';
import _manageheader from "../components/manageheader";
import _side from '../components/menu';
import {Button, Form, Input, InputNumber, Layout, message} from "antd";
import {Redirect} from "react-router";
import PicturesWall from "../components/PictureWall";
import * as bookService from "../service/BookService";
const { Header, Sider } = Layout;
const { TextArea } = Input;
class  _newBookpage extends React.Component{
    constructor(props) {
        super(props);
        this.state={
          bookImage:""
        };
    }
    changeImage = value =>{
        this.setState({bookImage:value});
        console.log(this.state);
    }
    onFinish = values => {
        if(values.bookName===""||values.bookName===undefined||values.bookRepertory===undefined||values.bookPrice===undefined){
            message.error("书名和库存、价格信息不可缺失");
            return;
        }
        let num = Number(values.bookPrice);
        if(isNaN(num)){
            message.error("价格信息必须为数字");
            return;
        }
        if(values.bookPrice.indexOf(".")!==-1){
            message.error("价格信息必须为整数");
            return;
        }
        let user_token = sessionStorage.getItem('userToken').toString();
        let book_json = {
            token:user_token,
            name:values.bookName,
            author:(values.bookAuthor===undefined?"":values.bookAuthor),
            price:('$'+values.bookPrice),
            ISBN:(values.bookISBN===undefined?"":values.bookISBN),
            repertory:parseInt(values.bookRepertory),
            information:(values.bookInformation===undefined?"":values.bookInformation),
            image:this.state.bookImage,
        };
        let callback = () =>{
            window.location.reload(true);
        };
        bookService.createBook(book_json,callback);
    };

    onFinishFailed = errorInfo => {
        console.log('Failed:', errorInfo);
    };
    render() {
        return (
            <div>
                {sessionStorage.length ===0 ?<Redirect to="/login"/>:(
                    <Layout className="full-height">
                        <Header className="header">
                            <_manageheader />
                        </Header>
                        <Layout >
                            <Sider width={200} className="site-layout-background">
                                <_side switchKey='5'/>
                            </Sider>
                            <Layout style={{padding: '0 5% 5%'}}>
                                <h1>书籍创建</h1>
                                <Form
                                    labelCol={{ span: 4 }}
                                    wrapperCol={{ span: 14 }}
                                    layout="horizontal"
                                    initialValues={{ size: 'middle' }}
                                    size='large'
                                    onFinish={this.onFinish}
                                    onFinishFailed={this.onFinishFailed}
                                >
                                    <Form.Item label="书籍名称" name="bookName">
                                        <Input />
                                    </Form.Item>
                                    <Form.Item label="书籍作者" name="bookAuthor">
                                        <Input />
                                    </Form.Item>
                                    <Form.Item label="书籍价格" name="bookPrice">
                                        <Input addonBefore="$" suffix="元"/>
                                    </Form.Item>
                                    <Form.Item label="书籍ISBN" name="bookISBN">
                                        <Input />
                                    </Form.Item>
                                    <Form.Item label="书籍余量" name="bookRepertory">
                                        <InputNumber min={0} defaultValue={0}/>
                                    </Form.Item>
                                    <Form.Item label="书籍简介" name="bookInformation">
                                        <TextArea rows={5} />
                                    </Form.Item>
                                    <Form.Item label="书籍封面" name="bookImage">
                                        <PicturesWall imageSrc={""} onImageChange={this.changeImage}/>
                                    </Form.Item>
                                    <Form.Item>
                                        <Button type="primary"  htmlType="submit">
                                            创建书籍
                                        </Button>
                                    </Form.Item>
                                </Form>
                            </Layout>

                        </Layout>
                    </Layout>
                )}
            </div>
        );
    }
}
export default  _newBookpage;
