import React from 'react';
import {Col, Layout, Row,Input} from "antd";
import {Redirect} from "react-router";
import _manageheader from "../components/manageheader";
import _side from "../components/menu";
import UserExcel from "../components/userExcel";
const { Header, Sider } = Layout;
const { Search } = Input;
class  _manageUserpage extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            searchValue:"",
        };

    };
    search = value =>{
        this.setState({searchValue:value});
    };
    render() {
        return (
            <div>
                {sessionStorage.length ===0 ?<Redirect to="/login"/>:(
                    <Layout className="full-height">
                        <Header className="header">
                            <_manageheader />
                        </Header>
                        <Layout >
                            <Sider width={200} className="site-layout-background">
                                <_side switchKey='7'/>
                            </Sider>
                            <Layout style={{padding: '0 5% 5%'}}>
                                <br/>
                                <Row>
                                    <Col span={6}>
                                    </Col>
                                    <Col span={4}></Col>
                                    <Col span={14}>
                                        <Search
                                            placeholder="输入用户名搜索"
                                            enterButton="搜索"
                                            size="large"
                                            onSearch={value => this.search(value)}
                                        />
                                    </Col>
                                </Row>
                                <br/>
                                <UserExcel filterText = {this.state.searchValue}/>
                            </Layout>

                        </Layout>
                    </Layout>
                )}
            </div>
        );
    }
}
export default  _manageUserpage;
