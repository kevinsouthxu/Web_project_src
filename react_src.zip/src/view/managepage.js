import { Layout,} from 'antd';
import 'antd/dist/antd.css';
import React from 'react';
import _manageheader from "../components/manageheader";
import _side from '../components/menu';
import BookExcel from "../components/bookExcel";
import '../lib/style1.css';
import '../lib/bootstrap.min.css';
import {Redirect} from "react-router";

const { Header, Sider } = Layout;

class  _managepage extends React.Component{
    books = this.props.books;
    render() {
        return (
            <div>
                {sessionStorage.length ===0 ?<Redirect to="/login"/>:(
            <Layout className="full-height">
                <Header className="header">
                    <_manageheader />
                </Header>
                <Layout >
                    <Sider width={200} className="site-layout-background">
                        <_side switchKey='5'/>
                    </Sider>
                    <Layout style={{padding: '0 5% 5%'}}>
                        <BookExcel books={this.books}/>
                    </Layout>

                </Layout>
            </Layout>
                    )}
            </div>
        );
    }
}
export default  _managepage;
