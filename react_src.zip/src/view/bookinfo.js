import { Layout, Descriptions, Badge,Result, Button,Spin} from 'antd';
import 'antd/dist/antd.css';
import React from 'react';
import _manageheader from "../components/manageheader";
import _side from '../components/menu';
import {history} from '../utils/history';
import '../lib/style1.css';
import '../lib/bootstrap.min.css';
import {Redirect} from "react-router";
import * as bookService from '../service/BookService';

const { Header, Sider } = Layout;
let bookId = -1;
let book = {};
class  _bookinfo extends React.Component{
    books = this.props.books;
    constructor(props) {
        super(props);
        const state = history.location.state;
        const callback = back_data =>{
            book = back_data;
            console.log(book);
            this.setState({});
        };
        if(state!== undefined && state.hasOwnProperty("bookId")) {
            bookId = state.bookId;
            history.location.state = {};
            let data = {
                bookId:bookId
            }
            bookService.findBook(data,callback);
        }
    };
    isEmpty = json =>{
        for(var name in json)
        {
            if(json.hasOwnProperty(name))
            {
                return false;
            }
        }
        return true;
    };
    backHome = () =>{
        history.replace("/");
    };
    render() {
        return (
            <div>
                {sessionStorage.length ===0 ?<Redirect to="/login"/>:(
                    <Layout className="full-height">
                        <Header className="header">
                            <_manageheader />
                        </Header>
                        <Layout >
                            <Sider width={200} className="site-layout-background">
                                <_side />
                            </Sider>
                            <Layout style={{padding: '0 5% 5%',background:"#ffffff"}}>
                                {(bookId === -1)?<div>
                                        <Result
                                            status="404"
                                            title="404"
                                            subTitle="Sorry, the page you visited does not exist."
                                            extra={<Button type="primary" onClick={this.backHome}>Back Home</Button>}
                                        />
                                    </div>:
                                    <div>
                                        {this.isEmpty(book)?<div style={{textAlign:"center"}}><Spin style={{marginTop:"100px"}} size="large"/></div>:
                                            <div>
                                                <br/>
                                            <Descriptions title="书籍信息" bordered layout="vertical">
                                            <Descriptions.Item label="书籍名称">{book.name}</Descriptions.Item>
                                            <Descriptions.Item label="书籍作者">{book.author}</Descriptions.Item>
                                            <Descriptions.Item label="书籍价格">{book.price}</Descriptions.Item>
                                            <Descriptions.Item label="售卖情况" span={3}>
                                                <Badge  status={book.repertory > 0?"processing":"error"}
                                                        text={book.repertory > 0?"正在售卖 库存：" + book.repertory:"该书库存为 "+book.repertory} />
                                            </Descriptions.Item>
                                            <Descriptions.Item label="书籍封面">
                                                <img src={book.image.base64} alt ={book.src} style={{width:'100%'}}></img>
                                            </Descriptions.Item>
                                            <Descriptions.Item label="书籍简介" span={3}>
                                                {book.information}
                                            </Descriptions.Item>

                                        </Descriptions>
                                            </div>}
                                    </div>}
                            </Layout>

                        </Layout>
                    </Layout>
                )}
            </div>
        );
    }
}
export default  _bookinfo;