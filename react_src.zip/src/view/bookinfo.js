import {
    Layout,
    Descriptions,
    Badge,
    Result,
    Button,
    Spin,
    Form,
    Input,
    InputNumber, message
} from 'antd';
import 'antd/dist/antd.css';
import React from 'react';
import _manageheader from "../components/manageheader";
import _side from '../components/menu';
import {history} from '../utils/history';
import '../lib/style1.css';
import '../lib/bootstrap.min.css';
import {Redirect} from "react-router";
import * as bookService from '../service/BookService';
import {EditTwoTone} from "@ant-design/icons";
import PicturesWall from "../components/PictureWall";
const { Header, Sider } = Layout;
let bookId = -1;
let book = {};
const { TextArea } = Input;
class  _bookinfo extends React.Component{
    books = this.props.books;
    constructor(props) {
        super(props);
        const state = history.location.state;
        const callback = back_data =>{
            book = back_data;
            this.setState({});
        };
        if(state!== undefined && state.hasOwnProperty("bookId")) {
            bookId = state.bookId;
            history.location.state = {};
            let data = {
                bookId:bookId
            }
            bookService.findBook(data,callback);
        }
        this.state={
            bookName:"",
            bookAuthor:"",
            bookPrice:"",
            bookISBN:"",
            bookRepertory:"",
            bookInformation:"",
            bookImage:"",
            isEditing:false,
        };
    };

    onFinish = values => {
        console.log('Success:', values);
    };

    onFinishFailed = errorInfo => {
        console.log('Failed:', errorInfo);
    };

    isEmpty = json =>{
        for(var name in json)
        {
            if(json.hasOwnProperty(name))
            {
                return false;
            }
        }
        return true;
    };
    edit = () =>{
        this.setState({
            bookName:book.name,
            bookAuthor:book.author,
            bookPrice:book.price,
            bookISBN:book.ISBN,
            bookRepertory:book.repertory,
            bookInformation:book.information,
            bookImage:book.image.base64,
            isEditing:true,
        });
    };
    save = () =>{
        let num = Number(this.state.bookPrice.substr(1));
        if(isNaN(num)){
            message.error("价格信息必须为数字");
            return;
        }
        if(this.state.bookPrice.indexOf(".")!==-1){
            message.error("价格信息必须为整数");
            return;
        }
        let book_json = {
            Id:bookId.toString(),
            name:this.state.bookName,
            author:this.state.bookAuthor,
            price:this.state.bookPrice,
            ISBN:this.state.bookISBN,
            repertory:this.state.bookRepertory,
            information:this.state.bookInformation,
            image:this.state.bookImage,
        };
        let callback = () =>{
            window.location.reload(true);
        };
        bookService.changeBook(book_json,callback);
    };
    changeImage = value =>{
        // console.log(value);
        this.setState({bookImage:value});
    }

    backHome = () =>{
        history.replace("/");
    };
    examine = (value,type) =>{
        switch (type) {
            case 1:
                this.setState({bookName:value.target.value});
                break;
            case 2:
                this.setState({bookAuthor:value.target.value});
                break;
            case 3:
                this.setState({bookPrice:this.state.bookPrice.substr(0,1)+value.target.value});
                break;
            case 4:
                this.setState({bookISBN:value.target.value});
                break;
            case 5:
                this.setState({bookRepertory:value});
                break;
            case 6:
                this.setState({bookInformation:value.target.value});
                break;
        }
    };
    render() {
        return (
            <div>
                {sessionStorage.length ===0 ?<Redirect to="/login"/>:(
                    <Layout className="full-height">
                        <Header className="header">
                            <_manageheader />
                        </Header>
                        <Layout >
                            <Sider width={200} className="site-layout-background">
                                <_side />
                            </Sider>
                            <Layout style={{padding: '0 5% 5%',background:"#ffffff"}}>
                                {(bookId === -1)?<div>
                                        <Result
                                            status="404"
                                            title="404"
                                            subTitle="Sorry, the page you visited does not exist."
                                            extra={<Button type="primary" onClick={this.backHome}>Back Home</Button>}
                                        />
                                    </div>:
                                    <div>
                                        {this.isEmpty(book)?<div style={{textAlign:"center"}}><Spin style={{marginTop:"100px"}} size="large"/></div>:
                                            <div>
                                                <br/>
                                                {!this.state.isEditing?
                                            <Descriptions title="书籍信息" bordered layout="vertical">
                                                <Descriptions.Item label="书籍名称">{book.name}</Descriptions.Item>
                                                <Descriptions.Item label="书籍作者">{book.author}</Descriptions.Item>
                                                <Descriptions.Item label="书籍价格">{book.price}</Descriptions.Item>
                                                <Descriptions.Item label="书籍ISBN">{book.ISBN}</Descriptions.Item>
                                                <Descriptions.Item label="售卖情况" span={2}>
                                                    <Badge  status={book.repertory > 0?"processing":"error"}
                                                        text={book.repertory > 0?"正在售卖 库存：" + book.repertory:"该书库存为 "+book.repertory} />
                                                </Descriptions.Item>
                                                <Descriptions.Item label="书籍封面">
                                                    <img src={book.image.base64} alt ={book.src} style={{width:'100%'}}></img>
                                                </Descriptions.Item>
                                                <Descriptions.Item label="书籍简介" span={3}>
                                                    {book.information}
                                                </Descriptions.Item>

                                            </Descriptions>
                                                    :
                                                <Form
                                                    labelCol={{ span: 4 }}
                                                    wrapperCol={{ span: 14 }}
                                                    layout="horizontal"
                                                    initialValues={{ size: 'middle' }}
                                                    size='large'
                                                    onFinish={this.onFinish}
                                                    onFinishFailed={this.onFinishFailed}
                                                >
                                                    <Form.Item label="书籍名称">
                                                        <Input defaultValue={this.state.bookName} onChange={value=>this.examine(value,1)}/>
                                                    </Form.Item>
                                                    <Form.Item label="书籍作者">
                                                        <Input defaultValue={this.state.bookAuthor}
                                                               onChange={value=>this.examine(value,2)}/>
                                                    </Form.Item>
                                                    <Form.Item label="书籍价格">
                                                        <Input addonBefore="$" suffix="元"
                                                               defaultValue={this.state.bookPrice.substr(1)}
                                                               onChange={value=>this.examine(value,3)}/>
                                                    </Form.Item>
                                                    <Form.Item label="书籍ISBN">
                                                        <Input defaultValue={this.state.bookISBN}
                                                               onChange={value=>this.examine(value,4)}/>
                                                    </Form.Item>
                                                    <Form.Item label="书籍余量">
                                                        <InputNumber min={0} defaultValue={this.state.bookRepertory}
                                                                     onChange={value=>this.examine(value,5)}/>
                                                    </Form.Item>
                                                    <Form.Item label="书籍简介">
                                                        <TextArea rows={5}  defaultValue={this.state.bookInformation}
                                                                  onChange={value=>this.examine(value,6)}/>
                                                    </Form.Item>
                                                    <Form.Item label="书籍封面">
                                                        <PicturesWall imageSrc={this.state.bookImage} onImageChange={this.changeImage}/>
                                                    </Form.Item>
                                                </Form>
                                                }
                                            <br/><br/>
                                                {!this.state.isEditing?
                                                    <Button shape="round" size="large" onClick={this.edit}><EditTwoTone
                                                        twoToneColor="#8c8c8c"/>编辑</Button>:
                                                    <Button shape="round" size="large" onClick={this.save}>保存</Button>
                                                }
                                            </div>}
                                    </div>}
                            </Layout>

                        </Layout>
                    </Layout>
                )}
            </div>
        );
    }
}
export default  _bookinfo;
