import { Layout,} from 'antd';
import 'antd/dist/antd.css';
import React from 'react';
import _header from '../components/header';
import _side from '../components/menu';
import _bookCarousel from '../components/bookCarousel';
import _bookpage from "../components/bookpage";
import '../lib/style1.css';
import '../lib/bootstrap.min.css';
import {Redirect} from "react-router";

const { Header, Sider } = Layout;

class  _mainpage extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            filterText: '',
            findBook: false
        };
        this.handlefilterTextChange =
            this.handlefilterTextChange.bind(this);
        this.handlefindBookChange =
            this.handlefindBookChange.bind(this);
    }
    handlefilterTextChange(filterText){
        this.setState({filterText:filterText,findBook:false});
    }
    handlefindBookChange(){
        this.setState({findBook:true});
    }
    render() {
    return (
        <div>
            {sessionStorage.length ===0 ?<Redirect to="/login"/>:(
                <Layout className="full-height">
                    <Header className="header">
                        <_header filterText = {this.state.filterText}
                                 onFilterTextChange={this.handlefilterTextChange}
                                 onfindBookChange={this.handlefindBookChange}>
                        </_header>
                    </Header>
                    <Layout >
                        <Sider width={200} className="site-layout-background">
                            <_side />
                        </Sider>
                        <Layout style={{padding: '0 5% 5%'}}>
                            <_bookCarousel />
                            <_bookpage books={this.props.books} filterText={this.state.filterText}
                                       findBook={this.state.findBook}/>
                        </Layout>

                    </Layout>
                </Layout>
            )}
        </div>
    );
}
}
export default  _mainpage;