let postRequest = (url, json, callback) => {
    let formdata = new FormData();
    for(var key in json){
        formdata.append(key,json[key]);
    }
    let opts = {
        method: "POST",
        body: formdata,
    };


    fetch(url,opts)
        .then(response => response.json())
        .then(data => {
            callback(data);
        }).catch(function (ex) {
        console.log('failed', ex)
    });

};

let postRequestJson = (url, json, callback) => {
    console.log(json);
    let opts = {
        method: "POST",
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        },
        body: JSON.stringify(json),
    };

    fetch(url,opts)
        .then(response => response.json())
        .then(data => {
            callback(data);
        }).catch(function (ex) {
        console.log('failed', ex)
    });

};

let getRequest = (url,callback) => {
    fetch(url)
        .then(response => response.json())
        .then(data => {
            callback(data);
        }).catch(function (ex) {
        console.log('failed', ex)
    });

};

export {postRequest,getRequest,postRequestJson};
