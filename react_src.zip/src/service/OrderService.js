import {postRequest} from "../utils/ajax";
import * as userService from '../service/UserService';

export const deleteOrder = (data,back) => {
    const url = `http://localhost:8080/deleteOrderBytoken`;
    const callback = (data) => {
        if(data) {
            let token = sessionStorage.getItem("userToken");
            let user_data = {
                token:token
            }
            userService.getUser(user_data);
            console.log("data succeed");
            back(data);
        }
        else{
            console.log("data error");
        }
    };
    console.log(data);
    postRequest(url, data, callback);
};

export const findOrder = (data,back) => {
    const url = `http://localhost:8080/findOrderBytoken`;
    const callback = (data) => {
        if(data) {
            console.log(data);
            let token = sessionStorage.getItem("userToken");
            let user_data = {
                token:token
            }
            userService.getUser(user_data);
            console.log("data succeed");
            back(data);
        }
        else{
            console.log("data error");
        }
    };
    console.log(data);
    postRequest(url, data, callback);
};
