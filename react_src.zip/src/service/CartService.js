import {postRequest} from "../utils/ajax";
import {history} from '../utils/history';
import * as userService from '../service/UserService';


export const makeOrder = (data,back) => {
    const url = `http://localhost:8080/addOrderBytoken`;
    const callback = (data) => {
        if(data === true || data === false) {
            sessionStorage.removeItem('item', JSON.stringify(data));
            sessionStorage.removeItem('item_count', JSON.stringify(data));
            let token = sessionStorage.getItem("userToken");
            let user_data = {
                token:token
            }
            userService.getUser(user_data);
            history.push("/");
            console.log("data succeed");
            back(data);
        }
        else{
            console.log("data error");
        }
    };
    postRequest(url, data, callback);
};

