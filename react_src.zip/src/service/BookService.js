import {getRequest} from "../utils/ajax";

export const findBook = (data,back) => {
    const bookId = data.bookId;
    const url = `http://localhost:8080/findBook/` + bookId.toString();
    const callback = (data) => {
        if(data) {
            console.log("data succeed");
            back(data);
        }
        else{
            console.log("data error");
        }
    };
    console.log(data);
    getRequest(url,callback);
};