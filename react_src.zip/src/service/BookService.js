import {getRequest} from "../utils/ajax";
import {postRequestJson} from "../utils/ajax";
import {postRequest} from "../utils/ajax";

export const findBook = (data,back) => {
    const bookId = data.bookId;
    const url = `http://localhost:8080/findBook/` + bookId.toString();
    const callback = (data) => {
        if(data) {
            console.log("data succeed");
            back(data);
        }
        else{
            console.log("data error");
        }
    };
    console.log(data);
    getRequest(url,callback);
};

export const changeBook = (data,back) =>{
    const url = 'http://localhost:8080/changeBook';
    const callback = (back_data)=>{
        if(back_data){
            console.log("data succeed");
            back();
        }
        else{
            console.log("data error");
        }
    };
    postRequestJson(url,data,callback);
}

export const createBook = (data,back) =>{
    const url = 'http://localhost:8080/createBook';
    const callback = (back_data)=>{
        if(back_data){
            console.log("data succeed");
            back();
        }
        else{
            console.log("data error");
        }
    };
    postRequestJson(url,data,callback);
}

export const deleteBook = (data,back) =>{
    const url = 'http://localhost:8080/deleteBook';
    const callback = (back_data)=>{
        if(back_data){
            console.log(back_data);
            console.log("data succeed");
            back();
        }
        else{
            console.log("data error");
        }
    };
    postRequest(url,data,callback);
}
