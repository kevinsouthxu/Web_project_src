import {getRequest, postRequest} from "../utils/ajax";
import {history} from '../utils/history';
import {message} from 'antd';



export const login = (data) => {
    const url = `http://localhost:8080/login`;
    const callback = (data) => {
        if(data != -1 && data != 0) {
            sessionStorage.clear();
            sessionStorage.setItem('userToken',data);
            let token = sessionStorage.getItem("userToken");
            let user_data = {
                token:token
            }
            getUser(user_data);
            console.log(data);
            history.replace("/");
            console.log("login succeed");
            message.success("登录成功");
        }
        else{
            if(data == 0){
                message.error("您的帐户已经被禁用");
                console.log("login error");
            }
            else {
                message.error("登录失败，用户名或密码错误");
                console.log("login error");
            }
        }
    };
    console.log(data);
    postRequest(url, data, callback);
};

export const logout = (data) => {
    const url = `http://localhost:8080/logout`;

    const callback = (data) => {
        if(data === true) {
            sessionStorage.clear();
            history.push("/login");
            console.log("logout succeed");
        }
        else{
            console.log("logout error");
        }
    };
    postRequest(url, data, callback);
};

export const getUser = (data) => {
    const url = `http://localhost:8080/checkUserBytoken`;
    const callback = (data) => {
        if(data.status === null || data.status !== 500) {
            sessionStorage.setItem('user', JSON.stringify(data));
            console.log("data succeed");
        }
        else{
            console.log("data error");
        }
    };
    console.log(data);
    postRequest(url, data, callback);
};

export const register = (data) => {
    const url = `http://localhost:8080/register`;
    const callback = (data) => {
        if(data) {
            if(data.hasOwnProperty("SuccessType")){
                console.log("success register");
                message.success("成功注册，返回登陆页面");
                history.push("/login");
            }
            else{
                console.log("fail register");
                if(data.ErrorType === 0){
                    message.error("用户名已存在");
                }
                if(data.ErrorType === 1){
                    message.error("邮箱已被注册");
                }
            }
        }
        else{
            console.log("data error");
        }
    };
    postRequest(url, data, callback);
};

export const getUsers = back => {
    const url = `http://localhost:8080/getUsers`;
    const callback = (data) => {
        if(data) {
            console.log("data succeed");
            back(data);
        }
        else{
            console.log("data error");
        }
    };
    getRequest(url,callback);
};

export const ban = (data,call_back) => {
    const url = `http://localhost:8080/ban`;
    const callback = (data) => {
        if(data) {
            if(data.hasOwnProperty("SuccessType")){
                console.log("success ban");
                message.success("成功禁用："+data.SuccessMessage);
                call_back();
            }
            else{
                console.log("fail ban");
                message.error("禁用失败："+data.ErrorMessage);
            }
        }
        else{
            console.log("data error");
        }
    };
    postRequest(url, data, callback);
};

export const enable = (data,call_back) => {
    const url = `http://localhost:8080/enable`;
    const callback = (data) => {
        if(data) {
            if(data.hasOwnProperty("SuccessType")){
                console.log("success ban");
                message.success("成功启用："+data.SuccessMessage);
                call_back();
            }
            else{
                console.log("fail ban");
                message.error("启用失败："+data.ErrorMessage);
            }
        }
        else{
            console.log("data error");
        }
    };
    postRequest(url, data, callback);
};
