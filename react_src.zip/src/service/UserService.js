import {postRequest} from "../utils/ajax";
import {history} from '../utils/history';
import {message} from 'antd';



export const login = (data) => {
    const url = `http://localhost:8080/login`;
    const callback = (data) => {
        if(data != -1) {
            sessionStorage.clear();
            sessionStorage.setItem('userToken',data);
            console.log(data);
            history.push("/");
            console.log("login succeed");
            message.success("登录成功");
        }
        else{
            message.error("登录失败，用户名或密码错误");
            console.log("login error");
        }
    };
    console.log(data);
    postRequest(url, data, callback);
};

export const logout = (data) => {
    const url = `http://localhost:8080/logout`;

    const callback = (data) => {
        if(data === true) {
            sessionStorage.clear();
            history.push("/login");
            console.log("logout succeed");
        }
        else{
            console.log("logout error");
        }
    };
    postRequest(url, data, callback);
};

export const checkSession = (callback) => {
    const url = `http://localhost:8080/checkSession`;
    postRequest(url, {}, callback);
};

export const getUser = (data) => {
    const url = `http://localhost:8080/checkUserBytoken`;
    const callback = (data) => {
        if(data.status === null || data.status !== 500) {
            sessionStorage.setItem('user', JSON.stringify(data));
            console.log("data succeed");
        }
        else{
            console.log("data error");
        }
    };
    console.log(data);
    postRequest(url, data, callback);
};