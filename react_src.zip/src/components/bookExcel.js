import React, {useState} from 'react';
import {Form, Input, InputNumber, Popconfirm, Table} from 'antd';
import '../lib/style1.css';
import {history} from '../utils/history';
let listItems = [];
// for(let i =0;i<6;i++)
// {
//     listItems.push({
//         key:books[i].number,
//         name:books[i].name,
//         author:books[i].author,
//         ISBN:books[i].ISBN,
//         number:books[i].number,
//         src:books[i].src,
//         price:books[i].price,
//     });
// }

const EditableCell = ({
                           editing,
                           dataIndex,
                           title,
                           inputType,
                           record,
                           index,
                           children,
                           ...restProps
                       }) => {
    const inputNode = inputType === 'number' ? <InputNumber /> : <Input />;
    return (
        <td {...restProps}>
            {editing ? (
                <Form.Item
                    name={dataIndex}
                    style={{
                        margin: 0,
                    }}
                    rules={[
                        {
                            required: true,
                            message: `Please Input ${title}!`,
                        },
                    ]}
                >
                    {inputNode}
                </Form.Item>
            ) : (
                children
            )}
        </td>
    );
};

const EditableTable = () => {
    const [form] = Form.useForm();
    const [data, setData] = useState(listItems);
    const [editingKey, setEditingKey] = useState('');

    const isEditing = record => record.key === editingKey;

    const edit = record => {
        console.log(record);
        history.push("/bookinfo",{
            bookId:record.bookId
        });
    };

    const cancel = () => {
        setEditingKey('');
    };
    const save = async key => {
        try {
            const row = await form.validateFields();
            const newData = [...data];
            const index = newData.findIndex(item => key === item.key);

            if (index > -1) {
                const item = newData[index];
                newData.splice(index, 1, {...item, ...row});
                setData(newData);
                setEditingKey('');
            } else {
                newData.push(row);
                setData(newData);
                setEditingKey('');
            }
        } catch (errInfo) {
            console.log('Validate Failed:', errInfo);
        }
    };

    const columns = [
        {
            title: 'name',
            dataIndex: 'name',
            width: '15%',
            editable: true,
            sorter: (a, b) => a.name.length - b.name.length,
        },
        {
            title: 'author',
            dataIndex: 'author',
            width: '15%',
            editable: true,
        },
        {
            title: 'ISBN',
            dataIndex: 'ISBN',
            width: '20%',
            editable: true,
        },
        {
            title: 'number',
            dataIndex: 'number',
            width: '15%',
            editable: true,
            sorter: (a,b) => a.number - b.number
        },
        {
            title: 'src',
            dataIndex: 'src',
            width: '15%',
            editable: true,
        },
        {
            title: 'price',
            dataIndex: 'price',
            width: '15%',
            editable: true,
            sorter: (a,b) => a.price.slice(1,a.price.length) - b.price.slice(1,b.price.length)
        },
        {
            title: 'operation',
            dataIndex: 'operation',
            render: (_, record) => {
                const editable = isEditing(record);
                return editable ? (
                    <span>
            <a
                href="javascript:;"
                onClick={() => save(record.key)}
                style={{
                    marginRight: 8,
                }}
            >
              Save
            </a>
            <Popconfirm title="Sure to cancel?" onConfirm={cancel}>
              <a>Cancel</a>
            </Popconfirm>
          </span>
                ) : (
                    <div>
                         <a disabled={editingKey !== ''} onClick={() => edit(record)}>
                             Edit
                         </a>
                        <br/>
                        <Popconfirm title="Sure to delete?" onConfirm={() => handleDelete(record.key)}>
                            <a>Delete</a>
                        </Popconfirm>
                    </div>
                );
            },
        },
    ];
    const handleDelete = key => {
        const data = listItems;
        listItems = listItems.slice(0,0);
        data.forEach((books) =>{
            if(books.number === key)
                return;
            listItems.push({
                key:books.number,
                name:books.name,
                author:books.author,
                ISBN:books.ISBN,
                number:books.number,
                src:books.src,
                price:books.price,
            })
        });
        setData(listItems);
        setEditingKey('');
    };
    const mergedColumns = columns.map(col => {
        if (!col.editable) {
            return col;
        }

        return {
            ...col,
            onCell: record => ({
                record,
                inputType: (col.dataIndex === 'number')  ? 'number' : 'text',
                dataIndex: col.dataIndex,
                title: col.title,
                editing: isEditing(record),
            }),
        };
    });
    return (
        <Form form={form} component={false}>
            <Table
                components={{
                    body: {
                        cell: EditableCell,
                    },
                }}
                bordered
                dataSource={data}
                columns={mergedColumns}
                rowClassName="editable-row"
                pagination={{
                    onChange: cancel,
                }}
            />
        </Form>
    );
};
class BookExcel extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            dataSource : this.props.books,
        };
        listItems = this.state.dataSource;
    }
    render() {

        return (
            <EditableTable />
        );
    }
}
export default BookExcel;