import React, {useState} from 'react';
import {Form, Input, InputNumber, Popconfirm, Table} from 'antd';
import '../lib/style1.css';
import {history} from '../utils/history';
const { Search } = Input;
let listItems = [];
// for(let i =0;i<6;i++)
// {
//     listItems.push({
//         key:books[i].number,
//         name:books[i].name,
//         author:books[i].author,
//         ISBN:books[i].ISBN,
//         number:books[i].number,
//         src:books[i].src,
//         price:books[i].price,
//     });
// }

const EditableCell = ({
                           editing,
                           dataIndex,
                           title,
                           inputType,
                           record,
                           index,
                           children,
                           ...restProps
                       }) => {
    const inputNode = inputType === 'number' ? <InputNumber /> : <Input />;
    return (
        <td {...restProps}>
            {editing ? (
                <Form.Item
                    name={dataIndex}
                    style={{
                        margin: 0,
                    }}
                    rules={[
                        {
                            required: true,
                            message: `Please Input ${title}!`,
                        },
                    ]}
                >
                    {inputNode}
                </Form.Item>
            ) : (
                children
            )}
        </td>
    );
};

const EditableTable = () => {
    const [form] = Form.useForm();
    const [data, setData] = useState(listItems);
    const [editingKey, setEditingKey] = useState('');

    const isEditing = record => record.key === editingKey;

    const jump = record => {
        console.log(record);
        history.push("/bookinfo",{
            bookId:record.bookId
        });
    };

    const cancel = () => {
        setEditingKey('');
    };
    const save = async key => {
        try {
            const row = await form.validateFields();
            const newData = [...data];
            const index = newData.findIndex(item => key === item.key);

            if (index > -1) {
                const item = newData[index];
                newData.splice(index, 1, {...item, ...row});
                setData(newData);
                setEditingKey('');
            } else {
                newData.push(row);
                setData(newData);
                setEditingKey('');
            }
        } catch (errInfo) {
            console.log('Validate Failed:', errInfo);
        }
    };


    const columns = [
        {
            title: '书名',
            dataIndex: 'name',
            width: '15%',
            editable: true,
            sorter: (a, b) => a.name.length - b.name.length,

        },
        {
            title: '作者',
            dataIndex: 'author',
            width: '15%',
            editable: true,

        },
        {
            title: 'ISBN',
            dataIndex: 'ISBN',
            width: '20%',
            editable: true,

        },
        {
            title: '书数',
            dataIndex: 'number',
            width: '15%',
            editable: true,
            sorter: (a,b) => a.number - b.number,

        },
        {
            title: '价格',
            dataIndex: 'price',
            width: '15%',
            editable: true,
            sorter: (a,b) => a.price.slice(1,a.price.length) - b.price.slice(1,b.price.length),

        },
        {
            title: '操作',
            dataIndex: 'operation',
            render: (_, record) => {
                const editable = isEditing(record);
                return editable ? (
                    <span>
            <a
                href="javascript:;"
                onClick={() => save(record.key)}
                style={{
                    marginRight: 8,
                }}
            >
              Save
            </a>
            <Popconfirm title="Sure to cancel?" onConfirm={cancel}>
              <a>Cancel</a>
            </Popconfirm>
          </span>
                ) : (
                    <div>
                         <a disabled={editingKey !== ''} onClick={() => jump(record)}>
                             查看
                         </a>
                        <br/>
                        <Popconfirm title="确定删除吗" onConfirm={() => handleDelete(record)}>
                            <a>删除</a>
                        </Popconfirm>
                    </div>
                );
            },
        },
    ];



    const handleDelete = record => {
        let key = 0;
        if(record.key === undefined){
            key = record.bookId;
        }
        else{
            key = record.key;
        }
        console.log(record);
        console.log(key);
        const data = listItems;
        listItems = listItems.slice(0,0);
        data.forEach((books) =>{
            if(books.number === key)
                return;
            listItems.push({
                key:books.number,
                name:books.name,
                author:books.author,
                ISBN:books.ISBN,
                number:books.number,
                src:books.src,
                price:books.price,
            })
        });
        setData(listItems);
        console.log(listItems);
        setEditingKey('');
    };
    const mergedColumns = columns.map(col => {
        if (!col.editable) {
            return col;
        }

        return {
            ...col,
            onCell: record => ({
                record,
                inputType: (col.dataIndex === 'number')  ? 'number' : 'text',
                dataIndex: col.dataIndex,
                title: col.title,
                editing: isEditing(record),
            }),
        };
    });
    return (
        <Form form={form} component={false}>
            <Table
                components={{
                    body: {
                        cell: EditableCell,
                    },
                }}
                bordered
                dataSource={listItems}
                columns={mergedColumns}
                rowClassName="editable-row"
                pagination={{
                    onChange: cancel,
                }}
            />
        </Form>
    );
};


class BookExcel extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            dataSource : this.props.books,
        };
        listItems = this.state.dataSource;
        console.log(listItems);
    }
    search = value =>{
        const data = this.state.dataSource;
        listItems = listItems.slice(0,0);
        data.forEach((books) =>{
            if(books.name.indexOf(value)===-1)
                return;
            listItems.push({
                key:books.number,
                name:books.name,
                author:books.author,
                ISBN:books.ISBN,
                number:books.number,
                src:books.src,
                price:books.price,
            })
        });
        this.setState({});
    }
    render() {

        return (
            <div>
                <br/><br/>
                <Search
                    placeholder="输入书名相关信息"
                    enterButton="搜索"
                    size="large"
                    onSearch={value => this.search(value)}
                />
                <br/><br/>
            <EditableTable />
            </div>
        );
    }
}
export default BookExcel;
