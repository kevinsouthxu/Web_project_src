import React, { useContext, useState, useEffect, useRef } from 'react';
import {Table, Button, Popconfirm, Form, InputNumber,Typography,message} from 'antd';
import {ShoppingTwoTone} from "@ant-design/icons";
import * as cartService from '../service/CartService';
const { Text } = Typography;


const listItems = [];
 // for(let i =0;i<4;i++)
 // {
 //     listItems.push({
 //         key:books[i].number,
 //         Image:<img src={books[i].src} alt ={books[i].src} style={{width:'100%'}}></img>,
 //         name:books[i].name,
 //         author:books[i].author,
 //         price:books[i].price,
 //         amount: 1,
 //     });
 // }
  //到时候应以后端传入listItem的方式获取

const EditableContext = React.createContext();

const EditableRow = ({ index, ...props }) => {
    const [form] = Form.useForm();
    return (
        <Form form={form} component={false}>
            <EditableContext.Provider value={form}>
                <tr {...props} />
            </EditableContext.Provider>
        </Form>
    );
};

const EditableCell = ({
                          title,
                          editable,
                          children,
                          dataIndex,
                          record,
                          handleSave,
                          ...restProps
                      }) => {
    const [editing, setEditing] = useState(false);
    const inputRef = useRef();
    const form = useContext(EditableContext);
    useEffect(() => {
        if (editing) {
            inputRef.current.focus();
        }
    }, [editing]);

    const toggleEdit = () => {
        setEditing(!editing);
        form.setFieldsValue({
            [dataIndex]: record[dataIndex],
        });
    };
    const save = async e => {
        try {
            const values = await form.validateFields();
            toggleEdit();
            handleSave({ ...record, ...values });
        } catch (errInfo) {
            console.log('Save failed:', errInfo);
        }
    };

    let childNode = children;

    if (editable) {
        childNode = editing ? (
            <Form.Item
                style={{
                    margin: 0,
                }}
                name={dataIndex}
                rules={[
                    {
                        required: true,
                        message: `${title} is required.`,
                    },
                ]}
            >
                <InputNumber ref={inputRef} onPressEnter={save} onBlur={save} min={1}/>
            </Form.Item>
        ) : (
            <div
                className="editable-cell-value-wrap"
                style={{
                    paddingRight: 24,
                }}
                onClick={toggleEdit}
            >
                {children}
            </div>
        );
    }

    return <td {...restProps}>{childNode}</td>;
};

class _bookCartExcel extends React.Component {
    constructor(props) {
        super(props);
        this.columns = [
            {
                title: '封面',
                dataIndex: 'Image',
                width: '10%',
            },
            {
                title: '书名',
                dataIndex: 'name',
                width: '35%',
                sorter: (a, b) => a.name.length - b.name.length,
            },
            {
                title: '作者',
                dataIndex: 'author',
                width: '25%',
            },
            {
                title: '价格',
                dataIndex: 'price',
                width: '15%',
                sorter: (a,b) => a.price.slice(1,a.price.length) - b.price.slice(1,b.price.length)
            },
            {
                title: '个数',
                dataIndex: 'amount',
                width: '15%',
                editable: true,
            },
            {
                title: '操作',
                dataIndex: 'operation',
                render: (text, record) =>
                    this.state.dataSource.length >= 1 ? (
                        <Popconfirm title="Sure to delete?" onConfirm={() => this.handleDelete(record.key)}>
                            <a>Delete</a>
                        </Popconfirm>
                    ) : null,
            },
        ];
        listItems.splice(0,listItems.length);
        if(sessionStorage.getItem("item") !== null) {
            let array = JSON.parse(sessionStorage.getItem("item")).cart;
            let books = this.props.books;
            let counts = [];
            if(sessionStorage.getItem("item_count")!==null)
            {
                counts = JSON.parse(sessionStorage.getItem("item_count")).cart_count;
                for(let i = 0;i < array.length;i++)
                {
                    if(i >= counts.length)
                    counts.push(1);
                }
                let data = {
                    cart_count:counts
                };
                sessionStorage.setItem("item_count",JSON.stringify(data));
            }
            else
                {
                    for(let i = 0;i < array.length;i++)
                    {
                        counts.push(1);
                    }
                    let data = {
                        cart_count:counts
                    };
                    sessionStorage.setItem("item_count",JSON.stringify(data));
            }
            console.log(sessionStorage.getItem("item"));
            console.log(sessionStorage.getItem("item_count"));
            for(let i = 0;i < books.length;i++)
            {
                for(let j = 0;j < array.length;j++)
                {
                    if(array[j] === books[i].bookId)
                    {
                        let flag = true;
                        for(let k = 0;k < listItems.length;k++)
                        {
                            if(listItems[k].key === array[j])
                                flag = false;
                        }
                        if(flag)
                        listItems.push({
                            key: books[i].bookId,
                            Image: <img src={books[i].image.base64} alt={books[i].src} style={{width: '100%'}}></img>,
                            name: books[i].name,
                            author: books[i].author,
                            price: books[i].price,
                            amount: counts[j],
                        });
                    }
                }

            }
        }

        this.state = {
            dataSource : listItems,
            count: 6,
        };
    }

    handleOrder = () =>{
        console.log("ok");
        const callback = back_data =>{
            if(back_data === true) {
                message.success('下单成功，已更新个人数据');
            }
            else
                message.error('下单失败，书籍库存可能已空');
        };
        if(sessionStorage.getItem("item_count")!==null) {
            let array = JSON.parse(sessionStorage.getItem("item")).cart;
            if(array.length > 0)
            {
                let array_count = JSON.parse(sessionStorage.getItem("item_count")).cart_count;
                // let userId = JSON.parse(sessionStorage.getItem("user")).userId;
                let token = sessionStorage.getItem("userToken");
                console.log(token);
                let data = {
                    token:token,
                    cart:array,
                    cart_count:array_count
                }
                console.log(data);
                cartService.makeOrder(data,callback);
            }
        }
    };

    handleDelete = key => {
        const dataSource = [...this.state.dataSource];
        this.setState({
            dataSource: dataSource.filter(item => item.key !== key),
        });
        console.log(key);
        let index = -1;
        if(sessionStorage.getItem("item") !== null) {
            let array = JSON.parse(sessionStorage.getItem("item")).cart;
            for(let i = 0;i < array.length;i++)
            {
                if(array[i] === key)
                {
                    index = i;
                    break;
                }
            }
            array.splice(index,1);
            let data = {
              cart:array
            };
            sessionStorage.setItem("item",JSON.stringify(data));
            let array_amount = JSON.parse(sessionStorage.getItem("item_count")).cart_count;
            array_amount.splice(index,1);
            let data_count = {
                cart_count:array_amount
            };
            sessionStorage.setItem("item_count",JSON.stringify(data_count));
            console.log(sessionStorage.getItem("item"));
            console.log(sessionStorage.getItem("item_count"));
        }


    };


    handleSave = row => {
        const newData = [...this.state.dataSource];
        const index = newData.findIndex(item => row.key === item.key);
        const item = newData[index];
        console.log(row);
        newData.splice(index, 1, { ...item, ...row });
        this.setState({
            dataSource: newData,
        });
        let bookId_index = -1;
        if(sessionStorage.getItem("item") !== null) {
            let array = JSON.parse(sessionStorage.getItem("item")).cart;
            for(let i = 0;i < array.length;i++)
            {
                if(array[i] === row.key)
                {
                    bookId_index = i;
                    break;
                }
            }
            let array_amount = JSON.parse(sessionStorage.getItem("item_count")).cart_count;
            array_amount[bookId_index] = row.amount;
            let data_count = {
                cart_count:array_amount
            };
            sessionStorage.setItem("item_count",JSON.stringify(data_count));
            console.log(sessionStorage.getItem("item"));
            console.log(sessionStorage.getItem("item_count"));
        }

    };

    render() {
        const { dataSource } = this.state;
        const components = {
            body: {
                row: EditableRow,
                cell: EditableCell,
            },
        };
        const columns = this.columns.map(col => {
            if (!col.editable) {
                return col;
            }

            return {
                ...col,
                onCell: record => ({
                    record,
                    editable: col.editable,
                    dataIndex: col.dataIndex,
                    title: col.title,
                    handleSave: this.handleSave,
                }),
            };
        });
        return (
            <div>
                <br/><br/>
                <Table
                    components={components}
                    rowClassName={() => 'editable-row'}
                    bordered
                    dataSource={dataSource}
                    columns={columns}
                    summary={pageData => {
                        let totalCash = 0;
                        let totalCount = 0;

                        pageData.forEach(({price, amount}) => {
                            totalCash += price.slice(1,price.length) * amount;
                            totalCount += amount;
                        });
                        return (
                            <>
                                <tr>
                                    <th>Total</th>
                                    <td>
                                        <Text>--</Text>
                                    </td>
                                    <td>
                                        <Text>--</Text>
                                    </td>
                                    <td>
                                        <Text type="danger">{totalCash}</Text>
                                    </td>
                                    <td>
                                        <Text>{totalCount}</Text>
                                    </td>
                                </tr>
                            </>
                        );
                    }
                    }/>
                    <br/><br/>
                <Button shape="round" size="large" onClick={this.handleOrder}><ShoppingTwoTone   twoToneColor="#73d13d"/>下单</Button>
            </div>
        );
    }
}
export default _bookCartExcel;
