import React from 'react';
import '../lib/style1.css';
import {Descriptions,Badge,Button} from "antd";
import { ShoppingTwoTone ,DollarCircleTwoTone    } from '@ant-design/icons';

class _bookinformation extends React.Component{
    addtocart = key =>{
        if(sessionStorage.getItem("item") !== null)
        {
            let array = JSON.parse(sessionStorage.getItem("item")).cart;
            for(let i = 0;i < array.length ;i++){
                if(array[i] === key)
                    return;
            }
            array.push(key);
            let data = {
                cart:array
            };
            sessionStorage.setItem("item",JSON.stringify(data));
            console.log(sessionStorage.getItem("item"));
        }
        else
        {
            let data = {
                cart:[key]
            };
            sessionStorage.setItem("item",JSON.stringify(data));
        }
    }
    render(){
        const book = this.props.book;
        return(
            <div>

                <Descriptions title="" bordered>
                    <Descriptions.Item label="封面" span={3}>
                        <img src={book.image.base64} alt ={book.src} style={{width:'30%'}}></img>
                    </Descriptions.Item>
                    <Descriptions.Item label="书名" span={3}>{book.name}</Descriptions.Item>
                    <Descriptions.Item label="作者" span={3}>{book.author}</Descriptions.Item>
                    <Descriptions.Item label="ISBN" span={3}>{book.ISBN}</Descriptions.Item>
                    <Descriptions.Item label="销售状态" span={3}>
                        <Badge status={book.repertory > 0?"processing":"error"} text={"还剩："+book.repertory+"本"} />
                    </Descriptions.Item>
                    <Descriptions.Item label="价格" span={3}>{book.price}</Descriptions.Item>
                    <Descriptions.Item label="简介" span={3}>
                        {this.props.information}
                    </Descriptions.Item>
                </Descriptions>
                <br/>
                <Button shape="round" size="large"><DollarCircleTwoTone  twoToneColor="#fadb14"/>购买</Button>
                <br/>
                <br/>
                <Button shape="round" size="large" onClick={()=>this.addtocart(book.bookId)}><ShoppingTwoTone   twoToneColor="#73d13d"/>加入购物车</Button>
            </div>
        );
    }
}
export default _bookinformation;