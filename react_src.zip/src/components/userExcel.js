import React from 'react';
import {Table, Popconfirm,Spin} from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import * as userService from '../service/UserService';
import {postRequest} from "../utils/ajax";
const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
class UserExcel extends React.Component {
    constructor(props) {
        super(props);
        this.state ={
            loading: false,
            originData:[],
            data:[],
            columns : [
                {
                    title: '用户ID',
                    dataIndex: 'userId',
                },
                {
                    title: '用户名',
                    dataIndex: 'username',
                },
                {
                    title: '邮箱',
                    dataIndex: 'email',
                },
                {
                    title: '名',
                    dataIndex: 'firstname',
                },
                {
                    title: '姓',
                    dataIndex: 'lastname',
                },
                {
                    title: '是否为管理员',
                    dataIndex: 'isAdmin',
                },
                {
                    title: '是否被封禁',
                    dataIndex: 'isBan',
                },
                {
                    title: '操作',
                    dataIndex: 'operation',
                    render: (_, record) => {
                        return (
                            <div>
                                <Popconfirm title="确定启用吗" onConfirm={() => this.enable(record)}>
                                    <a>启用</a>
                                </Popconfirm>
                                <br/>
                                <Popconfirm title="确定禁用吗" onConfirm={() => this.ban(record)}>
                                    <a>禁用</a>
                                </Popconfirm>
                            </div>
                        );
                    },
                }
            ]
        }
        this.updateData();
    }

    updateData = () =>{
        const callback = back_data =>{
            for(let i = 0;i < back_data.length;i++){
                if(back_data[i].isAdmin === false){
                    back_data[i].isAdmin = "否";
                }
                else{
                    back_data[i].isAdmin = "是";
                }
                if(back_data[i].isBan === false){
                    back_data[i].isBan = "否";
                }
                else{
                    back_data[i].isBan = "是";
                }
            }
            let temp_data = [];
            for(let i = 0;i < back_data.length;i++){
                if(back_data[i].username.indexOf(this.props.filterText)!==-1){
                    temp_data.push(back_data[i]);
                }
            }
            this.setState({originData:back_data,data:temp_data});
        };
        userService.getUsers(callback);
    }


    enable = record =>{
        let json={
            admin_token:sessionStorage.getItem("userToken"),
            target_username:record.username,
        }
        let callback = () =>{
            this.updateData();
        };
        userService.enable(json,callback);
    }

    ban = record =>{
        let json={
            admin_token:sessionStorage.getItem("userToken"),
            target_username:record.username,
        }
        let callback = () =>{
            this.updateData();
        };
        userService.ban(json,callback);
    }
    componentWillReceiveProps(nextProps) {//componentWillReceiveProps方法中第一个参数代表即将传入的新的Props
        let temp = [];
        for(let i = 0;i < this.state.originData.length;i++){
            if(this.state.originData[i].username.indexOf(nextProps.filterText)!==-1)
                temp.push(this.state.originData[i]);
        }
        this.setState({data:temp});
    }



    render() {
        return (
            <div>
                {this.state.data.length===0?<Spin indicator={antIcon} />:
                    <Table columns={this.state.columns} dataSource={this.state.data} scroll={{ y: 380, x: '50vw' }} />}
            </div>
        );
    }
}

export default UserExcel;
