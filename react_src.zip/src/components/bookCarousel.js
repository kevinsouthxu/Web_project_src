import { Carousel } from 'antd';
import React from 'react';
import '../lib/style1.css';
class _bookCarousel extends React.Component{
    render(){
        return(
            <Carousel autoplay>
                <div >
                        <img src={[require('../img/1.jpg')]} alt ="1.jpg" style={{width:'100%'}}></img>
                </div>
                <div>
                        <img src={[require('../img/2.jpg')]} alt ="2.jpg" style={{width:'100%'}}></img>
                </div>
                <div>
                        <img src={[require('../img/3.jpg')]} alt ="3.jpg" style={{width:'100%'}}></img>
                </div>
                <div>
                        <img src={[require('../img/4.jpg')]} alt ="4.jpg" style={{width:'100%'}}></img>
                </div>
            </Carousel>
        );
    }
}
export default _bookCarousel;