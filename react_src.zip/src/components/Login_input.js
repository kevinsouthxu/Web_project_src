import React from 'react';
import {Form, Input, Button, Checkbox, message} from 'antd';
import 'antd/dist/antd.css';
import '../lib/login.css';
import * as userService from '../service/UserService';
import {Icon} from '@ant-design/compatible';
import {history} from '../utils/history';

class LoginForm extends React.Component {

    onFinish = values => {
        console.log('Success:', values);
        if((values.username===""||values.username===undefined)
            || (values.password===""||values.password===undefined)){
            message.error("用户必须同时输入用户名和密码");
            return;
        }
        userService.login(values);
    };

    onFinishFailed = errorInfo => {
        console.log('Failed:', errorInfo);
    };

    onRegister = () =>{
        history.push("/register");
    };

    render() {

        return (
            <Form
                name="basic"
                initialValues={{ remember: true }}
                onFinish={this.onFinish}
                onFinishFailed={this.onFinishFailed}>
                <Form.Item
                    label="用户名"
                    name="username"
                >
                        <Input
                            prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                            placeholder="请输入用户名"
                        />
                </Form.Item>
                <Form.Item
                    label="密码"
                    name="password"
                >
                        <Input
                            prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                            type="password"
                            placeholder="请输入密码"
                        />
                </Form.Item>
                <Form.Item>
                    <Checkbox>记住账号</Checkbox>
                    <a className="login-form-forgot" href="">
                        忘记密码
                    </a>
                    <Button type="primary" htmlType="submit" className="login-form-button">
                        登录
                    </Button>
                    Or <a onClick={this.onRegister}>注册账号</a>
                </Form.Item>
            </Form>
        );
    }
}



export default LoginForm;
