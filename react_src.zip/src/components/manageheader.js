import React from 'react';
import '../lib/style1.css';
import '../lib/bootstrap.min.css';

class _manageheader extends React.Component{
    constructor(props) {
        super(props);
        let token = sessionStorage.getItem("userToken");
        this.state = {
            admin:false,
        };
        if(token<=10000){
            this.state = {
                admin:true,
            };
        }
    }
    render(){
        return(
            <div>
                <div className="row">
                    <div id="header">
                        <div className="col-md-1"></div>
                        <div className="col-md-1">
                            <div id="circle">
                            </div>
                        </div>
                        <div>
                            <h1 className="Content-left">E-Book</h1>
                            {(this.state.admin===true)?(<h3 className="Content-left-admin">管理员模式</h3>):null}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default _manageheader;
