import React from 'react';
import '../lib/style1.css';
import '../lib/bootstrap.min.css';

class _manageheader extends React.Component{
    render(){
        return(
            <div>
                <div className="row">
                    <div id="header">
                        <div className="col-md-1"></div>
                        <div className="col-md-1">
                            <div id="circle">
                            </div>
                        </div>
                        <div>
                            <h1 className="Content-left">E-Book</h1>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default _manageheader;