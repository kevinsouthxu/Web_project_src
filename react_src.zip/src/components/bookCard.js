import { Card,  } from 'antd';
import React from 'react';
import '../lib/style1.css';

class _bookcard extends React.Component{
    handleClick = () =>{
        console.log("clicked: "+this.props.books.author);
        this.props.handld_Click(this.props.books.number);
    };

    render(){

        return(
            <div className="site-card-wrapper">
                <Card onClick={this.handleClick} hoverable>
                    <img src={this.props.books.image.base64} alt ={this.props.books.src} style={{width:'30%',height:'100px'}}></img><br/>
                    <div>
                        书名：{this.props.books.name}<br></br>
                        作者：{this.props.books.author}
                    </div>
                    <div className="priceright">
                        <p style={{font:'10px'}}>{this.props.books.price}</p>
                    </div>
                </Card>
            </div>
        );
    }

}
export default _bookcard;
