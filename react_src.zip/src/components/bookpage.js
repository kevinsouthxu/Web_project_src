import React from 'react';
import _bookcard from "./bookCard";
import _bookinformation from "./bookinformation";
import {  Drawer,Col, Row } from 'antd';

class _bookpage extends React.Component{
    state = { visible: false,id:0,information: "" };
    handleClick = key  =>{
      console.log(key);
      const callback = () =>{
          this.setState({
              visible: true,
              id:key,
          });
          document.body.style.overflow = 'hidden'; //防止页面滚动
      };
      this.getBooks(key,callback);

    };
    getBooks = (key,callback) =>{
            fetch("http://localhost:8080/findBook/" + key)
                .then(response => response.json())
                .then(data => {
                    this.setState({information: data.information,book:data});
                    callback();
                }).catch(function (ex) {
                console.log('parsing failed', ex)
            });
    };
    onClose = () =>{
      console.log("close");
      this.setState({
          visible:false,
          id:0
      });
        document.body.style.overflow = 'scroll';
    };
    render() {
        const rows = [];
        const table = [];
        let number = 0;
        let temprow_1 = 0;
        let temprow_2 = 0;
        const filterText = this.props.filterText;
        const findBook = this.props.findBook;
        this.props.books.forEach((books) => {
            if ((books.author.indexOf(filterText) === -1)
                && (books.name.indexOf(filterText) === -1)
                && (books.ISBN.indexOf(filterText) === -1)
                && findBook
            ) {
                return;
            }
            rows.push(
                // eslint-disable-next-line react/jsx-pascal-case
                <_bookcard books={books} handld_Click={this.handleClick}/>
            );
        });
        rows.forEach((row) => {
            if(number === 2)
            {
                number = 0;
                table.push(
                    <Row >
                        <Col span={8}>
                            {temprow_1}
                        </Col>
                        <Col span={8}>
                            {temprow_2}
                        </Col>
                        <Col span={8}>
                            {row}
                        </Col>
                    </Row>
                );
            }
            else if(number === 1)
            {
                number = 2;
                temprow_2 = row;
            }
            else if(number === 0)
            {
                number = 1;
                temprow_1 = row;
            }

        });
        if(number === 1)
        {
            table.push(
                <Row glutter={16}>
                    <Col span={8}>
                        {temprow_1}
                    </Col>
                </Row>
            );
        }
        if(number === 2)
        {
            table.push(
                <Row glutter={16}>
                    <Col span={8}>
                        {temprow_1}
                    </Col>
                    <Col span={8}>
                        {temprow_2}
                    </Col>
                </Row>
            );
        }
        return (
            <div style={{height:'295px'}}>
                {table}
                <Drawer
                    title="买书?"
                    placement="right"
                    closable={false}
                    width={450}
                    onClose={this.onClose}
                    visible={this.state.visible}
                >
                    <div>{this.state.visible?
                        // eslint-disable-next-line react/jsx-pascal-case
                        <_bookinformation book={this.state.book} information={this.state.information}/>
                    :null}</div>
                </Drawer>
            </div>
        );
    }
}
export default _bookpage;