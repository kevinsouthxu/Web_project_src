import React from 'react';
import {Form, Input, Button, Checkbox, message} from 'antd';
import 'antd/dist/antd.css';
import '../lib/login.css';
import * as userService from '../service/UserService';
import {Icon} from '@ant-design/compatible';

class RegisterForm extends React.Component {

    onFinish = values => {
        console.log('Success:', values);
        if((values.username===""||values.username===undefined)
            || (values.password===""||values.password===undefined)
            || (values.repeat_password===""||values.repeat_password===undefined)
            || (values.email===""||values.email===undefined)){
            message.error("注册时填空项不可缺少");
            return;
        }
        if(values.password !== values.repeat_password){
            message.error("输入密码与重复输入密码不符");
            return;
        }
        let reg=/^\w+@[a-zA-Z0-9]{2,10}(?:\.[a-z]{2,4}){1,3}$/;
        if(!reg.test(values.email)){
            message.error("邮箱地址格式不正确");
            return;
        }
        let infor_json= {
          username:values.username,
          password:values.password,
          email:values.email
        };
        userService.register(infor_json);
    };

    onFinishFailed = errorInfo => {
        console.log('Failed:', errorInfo);
    };


    render() {

        return (
            <Form
                name="basic"
                initialValues={{ remember: true }}
                onFinish={this.onFinish}
                onFinishFailed={this.onFinishFailed}>
                <Form.Item
                    label="注册用户名"
                    name="username"
                >
                    <Input
                        prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                        placeholder="请输入要注册的用户名"
                    />
                </Form.Item>
                <Form.Item
                    label="注册密码"
                    name="password"
                >
                    <Input
                        prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                        type="password"
                        placeholder="请输入要注册的密码"
                    />
                </Form.Item>
                <Form.Item
                    label="重复密码"
                    name="repeat_password"
                >
                    <Input
                        prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                        type="password"
                        placeholder="请再次输入要注册的密码"
                    />
                </Form.Item>
                <Form.Item
                    label="注册邮箱"
                    name="email"
                >
                    <Input
                        prefix={<Icon type="Mail" style={{ color: 'rgba(0,0,0,.25)' }} />}
                        placeholder="请输入要注册的邮箱"
                    />
                </Form.Item>
                <Form.Item>
                    <Button type="primary" htmlType="submit" className="login-form-button">
                        注册
                    </Button>
                </Form.Item>
            </Form>
        );
    }
}



export default RegisterForm;
