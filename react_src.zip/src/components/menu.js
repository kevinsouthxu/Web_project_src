import React from 'react';
import { Menu } from 'antd';
import '../lib/style1.css';
import {Link} from 'react-router-dom';
import { ShoppingCartOutlined , SolutionOutlined , BookOutlined , UserOutlined , EditOutlined   } from '@ant-design/icons';
class _side extends React.Component {
    constructor(props) {
        super(props);
        let token = sessionStorage.getItem("userToken");
        this.state = {
            admin:false,
            key:this.props.switchKey,
        };
        if(token<=10000){
            this.state = {
                admin:true,
                key:this.props.switchKey,
            };
        }
    };
    handleClick = e => {

    };
    render() {
        return (
            <Menu
                onClick={this.handleClick}
                style={{ height: '100%' ,  }}
                defaultOpenKeys={['sub1']}
                mode="inline"
                selectedKeys={[this.state.key]}
            >
                <Menu.Item key="1">
                    <Link to={{
                        pathname:'/',

                    }}>
                    <BookOutlined />
                    Books
                    </Link>
                </Menu.Item>
                <Menu.Item key="2">
                    <Link to={{
                        pathname:'/cart',

                    }}>
                    <ShoppingCartOutlined />
                    My carts
                    </Link>
                </Menu.Item>
                <Menu.Item key="3">
                    <Link to={{
                        pathname:'/order',

                    }}>
                    <SolutionOutlined />
                    My Orders
                    </Link>
                </Menu.Item>
                <Menu.Item key="4">
                    <Link to={{
                        pathname:'/login',

                    }}>
                        <UserOutlined />
                        My Profile
                    </Link>
                </Menu.Item>
                {this.state.admin?
                    <Menu.Item key="5">
                        <Link to={'/manage'}>
                            <EditOutlined />
                            Manage
                        </Link>
                    </Menu.Item>:null}
            </Menu>
        );
    }
}
export default _side;
