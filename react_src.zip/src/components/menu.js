import React from 'react';
import { Menu } from 'antd';
import '../lib/style1.css';
import {Link} from 'react-router-dom';
import { ShoppingCartOutlined , SolutionOutlined , BookOutlined , UserOutlined , EditOutlined   } from '@ant-design/icons';
class _side extends React.Component {
    handleClick = e => {
        console.log('click ', e);
    };
    render() {
        return (
            <Menu
                onClick={this.handleClick}
                style={{ height: '100%' ,  }}
                defaultSelectedKeys={['1']}
                defaultOpenKeys={['sub1']}
                mode="inline"

            >
                <Menu.Item key="1">
                    <Link to={'/'}>
                    <BookOutlined />
                    Books
                    </Link>
                </Menu.Item>
                <Menu.Item key="2">
                    <Link to={'/cart'}>
                    <ShoppingCartOutlined />
                    My carts
                    </Link>
                </Menu.Item>
                <Menu.Item key="3">
                    <Link to={'/order'}>
                    <SolutionOutlined />
                    My Orders
                    </Link>
                </Menu.Item>
                <Menu.Item key="4">
                    <Link to={'/login'}>
                        <UserOutlined />
                        My Profile
                    </Link>
                </Menu.Item>
                <Menu.Item key="5">
                    <Link to={'/manage'}>
                        <EditOutlined />
                        Manage
                    </Link>
                </Menu.Item>
            </Menu>
        );
    }
}
export default _side;