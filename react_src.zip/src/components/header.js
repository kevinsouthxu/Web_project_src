import React from 'react';
import '../lib/style1.css';
import '../lib/bootstrap.min.css';

import { Input } from 'antd';

const { Search } = Input;

class _header extends React.Component{
    constructor(props) {
        super(props);
        let token = sessionStorage.getItem("userToken");
        this.state = {
            admin:false,
        };
        if(token<=10000){
            this.state = {
                admin:true,
            };
        }
        this.handlefilterTextChange =
            this.handlefilterTextChange.bind(this);
        this.findbookChange =
            this.findbookChange.bind(this);
    }
    handlefilterTextChange(e) {
        this.props.onFilterTextChange(e.target.value);
    }
    findbookChange(e){
        this.props.onfindBookChange();
    }

    render(){
        const filterText = this.props.filterText;
        return(
        <div>
        <div className="row">
            <div id="header">
              <div className="col-md-1"></div>
              <div className="col-md-1">
                <div id="circle">
                </div>
              </div>
              <div>
                <h1 className="Content-left">E-Book</h1>
                  {(this.state.admin===true)?(<h3 className="Content-left-admin">管理员模式</h3>):null}
              </div>
              <div id="search" className="Content-right">
                <div>
                  <Search
                      placeholder="输入书籍相关信息"
                      onSearch={this.findbookChange}
                      // value => console.log(value),
                      style={{ width: 200 }}
                      value={filterText}
                      onChange={this.handlefilterTextChange}
                  />
                </div>
              </div>
            </div>
        </div>
        </div>
    );
    }

}
export default _header;
