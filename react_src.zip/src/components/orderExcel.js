import React from 'react';
import {Table, Popconfirm,Spin} from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import * as orderService from '../service/OrderService';
import {postRequest} from "../utils/ajax";
import * as userService from '../service/UserService';
const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
class OrderExcel extends React.Component {
    constructor(props) {
        super(props);
        // data = data.slice(0,0);
        this.state ={
            selectedRowKeys: [], // Check here to configure the default column
            loading: false,
            originData:[],
            data:[],
            bookdata:[],
            userdata:[],
            userorigindata:[],
            bookpage:false,
            userpage:false,
            columns : [
                {
                    title: '订单ID',
                    dataIndex: 'orderId',
                },
                {
                    title: '总价格',
                    dataIndex: 'total_price',
                },
                {
                    title: '书籍个数',
                    dataIndex: 'total_amount',
                },
                {
                    title: '对应用户ID',
                    dataIndex: 'userId',
                },
                {
                    title: '下单时间',
                    dataIndex: 'date',
                },
                {
                    title: '操作',
                    dataIndex: 'operation',
                    render: (_, record) => {
                        return (
                            <div>
                                <a onClick={() => this.jump(record)}>
                                    查看
                                </a>
                                <br/>
                                <Popconfirm title="确定删除吗" onConfirm={() => this.handleDelete(record)}>
                                    <a>删除</a>
                                </Popconfirm>
                            </div>
                        );
                    },
                }
            ],
            book_columns : [
                {
                    title: '图片',
                    dataIndex: 'src',
                    key: 'src',
                },
                {
                    title: '书名',
                    dataIndex: 'name',
                    key: 'name',
                },
                {
                    title: '个数',
                    dataIndex: 'amount',
                    key: 'amount',
                    sorter: (a,b) => a.amount - b.amount,
                    sortOrder:true,
                },
                {
                    title: '价钱',
                    dataIndex: 'price',
                    key: 'price',
                },
            ],
            usercolumns : [
                {
                    title: '用户ID',
                    dataIndex: 'userId',
                    key: 'userId',
                },
                {
                    title: '用户名',
                    dataIndex: 'username',
                    key: 'username',
                },
                {
                    title: '购书总数',
                    dataIndex: 'amount',
                    key: 'amount',
                },
                {
                    title: '购书总价格',
                    dataIndex: 'price',
                    key: 'price',
                    sorter: (a,b) => a.price - b.price,
                    sortOrder:true,
                },
            ]
        }
        const callback = back_data =>{
            for(let i = 0;i < back_data.length;i++){
                this.state.originData.push({
                        "orderId": back_data[i].orderId,
                        "total_price": back_data[i].total_price,
                        "total_amount": back_data[i].total_amount,
                        "order": back_data[i].order,
                        "userId": back_data[i].userId,
                        "date":back_data[i].date,
                        "books":[],
                    }
                );
                this.state.data.push({
                        "orderId": back_data[i].orderId,
                        "total_price": back_data[i].total_price,
                        "total_amount": back_data[i].total_amount,
                        "order": back_data[i].order,
                        "userId": back_data[i].userId,
                        "date": back_data[i].date,
                        "books":[],
                    }
                );
                this.findBooks(i,this.state.data[i].order);
            };
            this.setState({});
        };
        orderService.getOrders(callback);
        const user_callback = back_data =>{
            for(let i = 0;i < back_data.length;i++){
                if(back_data[i].isAdmin === false){
                    back_data[i].isAdmin = "否";
                }
                else{
                    back_data[i].isAdmin = "是";
                }
                if(back_data[i].isBan === false){
                    back_data[i].isBan = "否";
                }
                else{
                    back_data[i].isBan = "是";
                }
            }
            let temp_data = [];
            for(let i = 0;i < back_data.length;i++){
                    temp_data.push(back_data[i]);
            }
            this.setState({userorigindata:back_data});
        };
        userService.getUsers(user_callback);
        console.log(this.state.data);
    }

    findBooks = (index,orderarray) => {
        const url = `http://localhost:8080/findBooks`;
        const callback = (book_data) =>{
            for(let i = 0; i < book_data.length;i++)
            {
                this.state.data[index].books.push({
                    "bookId": book_data[i].bookId,
                    "src": <img src={book_data[i].image.base64} alt ={book_data[i].src} style={{width:'20%'}}></img>,
                    "name": book_data[i].name,
                    "amount": orderarray[i].amount,
                    "price": orderarray[i].amount * parseInt(book_data[i].price.substr(1))
                });
                this.state.originData[index].books.push({
                    "bookId": book_data[i].bookId,
                    "src": <img src={book_data[i].image.base64} alt ={book_data[i].src} style={{width:'20%'}}></img>,
                    "name": book_data[i].name,
                    "amount": orderarray[i].amount,
                    "price": orderarray[i].amount * parseInt(book_data[i].price.substr(1))
                });
            }
            this.setState({});
        };
        let array = [];
        for(let i = 0;i < orderarray.length;i++) {
            array.push(orderarray[i].book_id);
        }
        let book_data = {
            books:array
        };
        postRequest(url,book_data,callback);
    };

    jump = record =>{
        console.log(this.state.originData);
        console.log(this.state.data);
        console.log(record);
    }

    handleDelete = record =>{
        console.log(record);
    }
    componentWillReceiveProps(nextProps) {//componentWillReceiveProps方法中第一个参数代表即将传入的新的Props
        // console.log(nextProps);
        // console.log(this.state.originData);
        let temp = [];
        for(let i = 0;i < this.state.originData.length;i++){
            let date =parseInt(this.state.originData[i].date.substr(0,4)
                                      +this.state.originData[i].date.substr(5,2)
                                      +this.state.originData[i].date.substr(8,2));
            let flag = false;
            if(nextProps.filterText!=="")
                for(let j = 0;j < this.state.originData[i].books.length;j++){
                    if(this.state.originData[i].books[j].name.indexOf(nextProps.filterText)!==-1){
                        console.log("trueeeeeeeee");
                        flag = true;
                        break;
                    }
                }
            else
                flag = true;
            if(((date>=nextProps.startDate&&date<=nextProps.endDate)||(nextProps.startDate===0&&nextProps.endDate===0))
                &&flag
                )
                {
                temp.push(this.state.originData[i]);
            }
        }
        this.setState({data:temp});
        // console.log(this.state.data);
        if(nextProps.BookPage === true){
            this.state.bookdata.splice(0,this.state.bookdata.length);
            for(let i = 0;i < temp.length;i++){
                for(let j = 0;j < temp[i].books.length;j++){
                    let flag = false;
                    for(let k = 0; k < this.state.bookdata.length;k++){
                        if(this.state.bookdata[k].bookId === temp[i].books[j].bookId){
                            this.state.bookdata[k].amount += temp[i].books[j].amount;
                            this.state.bookdata[k].price += temp[i].books[j].price;
                            flag = true;
                            break;
                        }
                    }
                    if(!flag && temp[i].books[j].name.indexOf(nextProps.filterText)!==-1){
                        this.state.bookdata.push({
                            "bookId": temp[i].books[j].bookId,
                            "src": temp[i].books[j].src,
                            "name": temp[i].books[j].name,
                            "amount": temp[i].books[j].amount,
                            "price": temp[i].books[j].price,
                        });
                    }
                }
            }
            this.setState({bookpage:true,userpage:false});
            return;
        }
        if(nextProps.UserPage === true){
            console.log("here");
            this.state.userdata.splice(0,this.state.userdata.length);
            for(let i = 0;i < this.state.originData.length;i++){
                let flag = false;
                let date =parseInt(this.state.originData[i].date.substr(0,4)
                    +this.state.originData[i].date.substr(5,2)
                    +this.state.originData[i].date.substr(8,2));
                for(let j = 0;j < this.state.userdata.length;j++){
                    if(this.state.originData[i].userId === this.state.userdata[j].userId &&
                        ((date>=nextProps.startDate&&date<=nextProps.endDate)||(nextProps.startDate===0&&nextProps.endDate===0))){
                        this.state.userdata[j].amount += this.state.originData[i].total_amount;
                        this.state.userdata[j].price += this.state.originData[i].total_price;
                        flag = true;
                    }
                }
                if(!flag &&
                    ((date>=nextProps.startDate&&date<=nextProps.endDate)||(nextProps.startDate===0&&nextProps.endDate===0)))
                for(let j = 0;j < this.state.userorigindata.length;j++){
                    if(this.state.originData[i].userId === this.state.userorigindata[j].userId) {
                        this.state.userdata.push({
                            "userId": this.state.originData[i].userId,
                            "username": this.state.userorigindata[j].username,
                            "amount": this.state.originData[i].total_amount,
                            "price": this.state.originData[i].total_price,
                        });
                    }
                }
            }
            this.setState({userpage:true,bookpage:false});
            console.log(this.state.userdata);
            return;
        }
        this.state.bookpage=false;this.state.userpage=false;
        this.setState({});
    }



    render() {
        return (
            <div>
                {this.state.data.length===0?<Spin indicator={antIcon} />:
                    this.state.bookpage===true?<Table columns={this.state.book_columns} dataSource={[...this.state.bookdata]} scroll={{ y: 330, x: '50vw' }}/>:
                        this.state.userpage===true?<Table columns={this.state.usercolumns} dataSource={[...this.state.userdata]} scroll={{ y: 330, x: '50vw' }}/>:
                        <Table columns={this.state.columns} dataSource={[...this.state.data]} scroll={{ y: 330, x: '50vw' }}/>}
            </div>
        );
    }
}

export default OrderExcel;
