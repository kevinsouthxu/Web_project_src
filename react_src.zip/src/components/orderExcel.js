import React from 'react';
import {Table, Popconfirm,Spin} from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import * as orderService from '../service/OrderService';
import {postRequest} from "../utils/ajax";
const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
class OrderExcel extends React.Component {
    constructor(props) {
        super(props);
        // data = data.slice(0,0);
        this.state ={
            selectedRowKeys: [], // Check here to configure the default column
            loading: false,
            originData:[],
            data:[],
            columns : [
                {
                    title: '订单ID',
                    dataIndex: 'orderId',
                },
                {
                    title: '总价格',
                    dataIndex: 'total_price',
                },
                {
                    title: '书籍个数',
                    dataIndex: 'total_amount',
                },
                {
                    title: '对应用户ID',
                    dataIndex: 'userId',
                },
                {
                    title: '下单时间',
                    dataIndex: 'date',
                },
                {
                    title: '操作',
                    dataIndex: 'operation',
                    render: (_, record) => {
                        return (
                            <div>
                                <a onClick={() => this.jump(record)}>
                                    查看
                                </a>
                                <br/>
                                <Popconfirm title="确定删除吗" onConfirm={() => this.handleDelete(record)}>
                                    <a>删除</a>
                                </Popconfirm>
                            </div>
                        );
                    },
                }
            ]
        }
        const callback = back_data =>{
            for(let i = 0;i < back_data.length;i++){
                this.state.originData.push({
                        "orderId": back_data[i].orderId,
                        "total_price": back_data[i].total_price,
                        "total_amount": back_data[i].total_amount,
                        "order": back_data[i].order,
                        "userId": back_data[i].userId,
                        "date":back_data[i].date,
                        "books":[],
                    }
                );
                this.state.data.push({
                        "orderId": back_data[i].orderId,
                        "total_price": back_data[i].total_price,
                        "total_amount": back_data[i].total_amount,
                        "order": back_data[i].order,
                        "userId": back_data[i].userId,
                        "date": back_data[i].date,
                        "books":[],
                    }
                );
                this.findBooks(i,this.state.data[i].order);
            };
            this.setState({});
        };
        orderService.getOrders(callback);
        console.log(this.state.data);
    }

    findBooks = (index,orderarray) => {
        const url = `http://localhost:8080/findBooks`;
        const callback = (book_data) =>{
            for(let i = 0; i < book_data.length;i++)
            {
                this.state.data[index].books.push({
                    "bookId": book_data[i].bookId,
                    "src": <img src={book_data[i].image.base64} alt ={book_data[i].src} style={{width:'20%'}}></img>,
                    "name": book_data[i].name,
                    "amount": orderarray[i].amount,
                    "price": orderarray[i].amount * parseInt(book_data[i].price.substr(1))
                });
                this.state.originData[index].books.push({
                    "bookId": book_data[i].bookId,
                    "src": <img src={book_data[i].image.base64} alt ={book_data[i].src} style={{width:'20%'}}></img>,
                    "name": book_data[i].name,
                    "amount": orderarray[i].amount,
                    "price": orderarray[i].amount * parseInt(book_data[i].price.substr(1))
                });
            }
            this.setState({});
        };
        let array = [];
        for(let i = 0;i < orderarray.length;i++) {
            array.push(orderarray[i].book_id);
        }
        let book_data = {
            books:array
        };
        postRequest(url,book_data,callback);
    };

    jump = record =>{
        console.log(this.state.originData);
        console.log(this.state.data);
        console.log(record);
    }

    handleDelete = record =>{
        console.log(record);
    }
    componentWillReceiveProps(nextProps) {//componentWillReceiveProps方法中第一个参数代表即将传入的新的Props
        console.log(nextProps);
        console.log(this.state.originData);
        let temp = [];
        // if(!this.state.originData.hasOwnProperty("books"))
        //     return;
        for(let i = 0;i < this.state.originData.length;i++){
            let date =parseInt(this.state.originData[i].date.substr(0,4)
                                      +this.state.originData[i].date.substr(5,2)
                                      +this.state.originData[i].date.substr(8,2));
            let flag = false;
            if(nextProps.filterText!=="")
                for(let j = 0;j < this.state.originData[i].books.length;j++){
                    if(this.state.originData[i].books[j].name.indexOf(nextProps.filterText)!==-1){
                        console.log("trueeeeeeeee");
                        flag = true;
                        break;
                    }
                }
            else
                flag = true;
            if(((date>=nextProps.startDate&&date<=nextProps.endDate)||(nextProps.startDate===0&&nextProps.endDate===0))
                &&flag
                )
                {
                temp.push(this.state.originData[i]);
            }
        }
        this.setState({data:temp});
        console.log(this.state.data);
    }



    render() {
        return (
            <div>
                {this.state.data.length===0?<Spin indicator={antIcon} />:
                    <Table columns={this.state.columns} dataSource={this.state.data} />}
            </div>
        );
    }
}

export default OrderExcel;
