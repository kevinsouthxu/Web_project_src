import React from 'react';
import './App.css';
import BasicRoute from './Router';

import 'antd/dist/antd.css';

// class ActionLink extends React.Component{
//   handleClick(e){
//     e.preventDefault();
//     console.log('The Link was clicked');
//   }
//   render() {
//     return (
//         <div className="col-md-2">
//           <a href="#" role="button" id="otherpage" onClick={this.handleClick}>
//             {this.props.names}
//           </a>
//         </div>
//     );
//   }
// }
// class  Catalog_title extends React.Component {
//   handleClick(e) {
//     e.preventDefault();
//     console.log('The Link was clicked');
//   }
//
//   render() {
//     return (
//         <div>
//           <a href="#" role="button" id="prime_index" onClick={this.handleClick}>
//             {this.props.category}
//           </a>
//           <br></br>
//           <br></br>
//         </div>
//     );
//   }
// }
// class Catalog_row extends React.Component{
//   render(){
//     const species = this.props.species;
//     const name = species.name;
//     return(
//         <li id="nav"><a>{name}</a></li>
//     );
//   }
// }
// class Catalog_table extends React.Component{
//   render(){
//     const rows = [];
//     let lastCategory = null;
//     this.props.species.forEach((species) => {
//       if (species.category !== lastCategory) {
//         rows.push(
//             <Catalog_title
//              category = {species.category} />
//         );
//       }rows.push(
//           <Catalog_row
//               species = {species} />
//       );
//       lastCategory = species.category;
//     });
//     return(
//         <div>
//        <tbody>{rows}</tbody>
//         </div>
//     );
//   }
// }
// class Content_book extends React.Component{
//   render(){
//     const books = this.props.books;
//     const name = books.author;
//     const ISBN = books.ISBN;
//     const _src = books.src;
//     return(
//         <div className="col-sm-2" id="content_books">
//           <img src = {_src} alt = {books.number} className="img-rounded" ></img>
//           <div id = "oa_submeau">
//             <p>作者: {name}<br></br>
//                ISBN：{ISBN}</p>
//           </div>
//         </div>
//     );
//   }
// }




function App() {

  return (
    <BasicRoute  />
  );
}
export default App;
