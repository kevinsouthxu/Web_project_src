import React from 'react';
import {
  View,
  Text,
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  ScrollView,
  TouchableHighlight,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {SearchBar} from '../component/SearchBar';
import {Carousel} from '@ant-design/react-native';
import {apiUrl} from '../urlconfig';
const GETBOOKS_URL = apiUrl + '/getBooks';
const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    // backgroundColor: '#fff0f6',
  },
  name: {
    fontSize: 18,
    marginBottom: 8,
    marginLeft: 10,
    textAlign: 'left',
  },
  author: {
    fontSize: 10,
    marginLeft: 10,
    textAlign: 'left',
  },
  rightContainer: {
    flex: 1,
  },
  image: {
    width: 53,
    height: 100,
  },
  carousel: {
    width: '100%',
    height: '100%',
  },
  carouselcontainer: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: 150,
  },
  list: {
    paddingLeft: 10,
    paddingRight: 5,
    backgroundColor: '#fff0f6',
  },
  price: {
    fontSize: 20,
    textAlign: 'left',
    marginRight: 10,
    color: 'red',
  },
  linearGradient: {
    flex: 1,
    paddingLeft: 15,
    paddingRight: 15,
    borderRadius: 5,
  },
});
let books = [];
export class BookListScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      books: [],
      showBooks: [],
      isLoading: true,
    };
  }

  componentDidMount() {
    this.fetchBooks();
  }

  searchBooks(data) {
    var arr = [];
    var list = this.state.books;
    for (var i = 0; i < list.length; i++) {
      if (
        list[i].name.indexOf(data) >= 0 ||
        list[i].author.indexOf(data) >= 0 ||
        list[i].information.indexOf(data) >= 0 ||
        list[i].price.indexOf(data) >= 0
      ) {
        arr.push(list[i]);
      }
    }
    this.setState({
      showBooks: arr,
    });
  }

  cancel() {
    this.setState({
      showBooks: this.state.books,
    });
  }
  navigateToDetail({item}) {
    this.props.navigation.push('BookDetail', {detail: item});
  }
  fetchBooks() {
    fetch(GETBOOKS_URL, {
      method: 'GET',
    })
      .then((response) => response.json())
      .then((responseData) => {
        for (let i = 0; i < responseData.length; i++) {
          responseData[i].bookId = responseData[i].bookId.toString();
        }
        books = responseData;
        this.setState({
          isLoading: false,
          books: responseData,
          showBooks: responseData,
        });
        console.log(this.state.showBooks.length);
      })
      .catch((error) => {
        console.error(error);
      });
  }

  renderBook = ({item}) => {
    return (
      <TouchableHighlight
        onPress={() => {
          this.navigateToDetail({item});
          // console.log('Press: ' + item.bookId);
        }}>
        <LinearGradient
          colors={['#99ffff', '#33ffff', '#99bbff']}
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          style={styles.linearGradient}>
          <View style={styles.container}>
            <Image source={{uri: item.image.base64}} style={styles.image} />
            <View style={styles.rightContainer}>
              <Text style={styles.name}>书名：{item.name}</Text>
              <Text style={styles.author}>作者：{item.author}</Text>
            </View>
            <View>
              <Text style={styles.price}>{item.price}</Text>
            </View>
          </View>
        </LinearGradient>
      </TouchableHighlight>
    );
  };

  render() {
    let test = this.state.showBooks[0];
    if (this.state.isLoading) {
      return (
        <View style={{flex: 1, paddingTop: 340}}>
          <ActivityIndicator />
        </View>
      );
    } else {
      return (
        <ScrollView>
          <SearchBar
            searchBooks={(data) => this.searchBooks(data)}
            cancelSearching={() => this.cancel()}
          />
          <Carousel autoplay infinite>
            <View style={styles.carouselcontainer}>
              <Image source={require('../img/1.jpg')} style={styles.carousel} />
            </View>
            <View style={styles.carouselcontainer}>
              <Image source={require('../img/2.jpg')} style={styles.carousel} />
            </View>
            <View style={styles.carouselcontainer}>
              <Image source={require('../img/3.jpg')} style={styles.carousel} />
            </View>
            <View style={styles.carouselcontainer}>
              <Image source={require('../img/4.jpg')} style={styles.carousel} />
            </View>
          </Carousel>
          <FlatList
            data={this.state.showBooks}
            renderItem={this.renderBook}
            style={styles.list}
            keyExtractor={(item) => item.bookId}
          />
        </ScrollView>
      );
    }
  }
}
