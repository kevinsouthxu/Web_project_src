import React from 'react';
import {StyleSheet, View, Text, Dimensions, Alert} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import {Button, InputItem} from '@ant-design/react-native';
import LinearGradient from 'react-native-linear-gradient';
import {apiUrl} from '../urlconfig';
let {width} = Dimensions.get('window');
const LOGIN_URL = apiUrl + '/login';
var isSuccess;
// function fetchData(name, password) {
//   let formdata = new FormData();
//   formdata.append('username', name);
//   formdata.append('password', password);
//   fetch(LOGIN_URL, {
//     method: 'POST',
//     body: formdata,
//   })
//     .then((response) => {
//       return response.json();
//     })
//     .then((responseData) => {
//       isSuccess = responseData == -1 ? false : true;
//       if (isSuccess) {
//         AsyncStorage.setItem('token', responseData.toString(), function (
//           error,
//         ) {
//           if (error) {
//             alert('token存储失败');
//           } else {
//             this.props.navigation.navigate('Main');
//           }
//         });
//         // AsyncStorage.getItem('token', function (error, result) {
//         //   if (error) {
//         //     alert('token读取失败');
//         //   } else {
//         //     console.log(result);
//         //     // alert('读取完成');
//         //   }
//         // });
//       } else {
//         Alert.alert('用户名或密码错误');
//       }
//     })
//     .catch((error) => {
//       console.error(error);
//     });
// }
export class LoginScreen extends React.Component {
  static navigationOptions = {
    title: 'Login',
  };
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
    };
  }
  setName(text) {
    this.setState({
      username: text,
    });
  }
  navigateToMain() {
    this.props.navigation.replace('Main');
  }
  fetchData(name, password) {
    let that = this;
    let formdata = new FormData();
    formdata.append('username', name);
    formdata.append('password', password);
    fetch(LOGIN_URL, {
      method: 'POST',
      body: formdata,
    })
      .then((response) => {
        return response.json();
      })
      .then((responseData) => {
        isSuccess = responseData == -1 ? false : true;
        if (isSuccess) {
          AsyncStorage.setItem('token', responseData.toString(), function (
            error,
          ) {
            if (error) {
              alert('token存储失败');
            } else {
              // this.props.navigation.navigate('Main');
              that.navigateToMain();
            }
          });
          // AsyncStorage.getItem('token', function (error, result) {
          //   if (error) {
          //     alert('token读取失败');
          //   } else {
          //     console.log(result);
          //     // alert('读取完成');
          //   }
          // });
        } else {
          Alert.alert('用户名或密码错误');
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }
  setPassword(text) {
    this.setState({
      password: text,
    });
  }
  render() {
    return (
      <LinearGradient
        colors={['#ffb7dd', '#ff88c2', '#9999ff']}
        style={styles.linearGradient}>
        <View style={{flex: 1}}>
          <View style={styles.container}>
            <Text style={styles.titleStyle}>登录</Text>
            <InputItem
              style={styles.textInputStyle}
              onChangeText={(text) => this.setName(text)}
              value={this.state.username}
              placeholder={'请输入用户名'}
            />
            <InputItem
              style={styles.textInputStyle}
              placeholder="请输入密码"
              onChangeText={(text) => this.setPassword(text)}
              value={this.state.password}
              type="password"
            />
            <Button
              size="small"
              style={styles.loginBtnStyle}
              title="登录"
              onPress={() => {
                this.fetchData(this.state.username, this.state.password);
              }}>
              <Text style={styles.textStyle}>登录</Text>
            </Button>
            {/*设置*/}
            <View style={styles.settingStyle}>
              <Text>忘记密码</Text>
              <Text>注册</Text>
            </View>
          </View>
        </View>
      </LinearGradient>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    // 侧轴的对齐方式
    justifyContent: 'center',
    alignItems: 'center',
  },
  textInputStyle: {
    width: width * 0.9,
    height: 40,
    backgroundColor: 'white',
    textAlign: 'center',
    marginBottom: 5,
  },
  loginBtnStyle: {
    width: width * 0.5,
    height: 40,
    backgroundColor: 'white',
    marginTop: 30,
    marginBottom: 20,
    borderRadius: 30,
  },
  settingStyle: {
    width: width * 0.85,
    height: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  titleStyle: {
    fontSize: 40,
    alignItems: 'center',
    paddingBottom: 10,
  },
  linearGradient: {
    flex: 1,
    paddingLeft: 15,
    paddingRight: 15,
    borderRadius: 5,
  },
  textStyle: {
    fontSize: 30,
  },
});
