import React from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  DeviceEventEmitter,
  Image, Alert,
} from 'react-native';
import {apiUrl} from '../urlconfig';
import {Card, Button} from '@ant-design/react-native';
import AsyncStorage from '@react-native-community/async-storage';
const GETCART_URL = apiUrl + '/getCart';
const GETBOOKS_URL = apiUrl + '/findBooks';
const INCART_URL = apiUrl + '/increaseCart';
const DECART_URL = apiUrl + '/decreaseCart';
const ADDORDER_URL = apiUrl + '/addOrdermemory';
export class CartScreen extends React.Component {
  constructor(props) {
    super(props);
    console.log('opencart');
    this.state = {
      cartItems: [],
      finishFetch: false,
      token: 0,
    };
  }
  componentDidMount() {
    let that = this;
    let token = 0;
    AsyncStorage.getItem('token', function (error, result) {
      if (error) {
        alert('token读取失败');
      } else {
        token = result;
        that.state.token = token;
        console.log(token);
        that.fetchCartItems(parseInt(token));
      }
    });
    this.listener = DeviceEventEmitter.addListener('addCart', (message) => {
      console.log('update cart');
      that.fetchCartItems(parseInt(token));
      that.state.finishFetch = false;
    });
  }
  increaseItem = (bookId) => {
    console.log(bookId);
    let that = this;
    let formdata = new FormData();
    formdata.append('token', this.state.token);
    formdata.append('bookId', bookId);
    formdata.append('num', 1);
    fetch(INCART_URL, {
      method: 'POST',
      body: formdata,
    })
      .then((response) => response.json())
      .then((responseData) => {
        if (responseData == true) {
          for (let i = 0; i < that.state.cartItems.length; i++) {
            if (that.state.cartItems[i].bookId == bookId) {
              that.state.cartItems[i].bookCount =
                that.state.cartItems[i].bookCount + 1;
            }
          }
          that.setState({});
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };
  decreaseItem = (bookId) => {
    console.log(bookId);
    let that = this;
    let formdata = new FormData();
    formdata.append('token', this.state.token);
    formdata.append('bookId', bookId);
    formdata.append('num', 1);
    fetch(DECART_URL, {
      method: 'POST',
      body: formdata,
    })
      .then((response) => response.json())
      .then((responseData) => {
        if (responseData == true) {
          for (let i = 0; i < that.state.cartItems.length; i++) {
            if (that.state.cartItems[i].bookId == bookId) {
              that.state.cartItems[i].bookCount =
                that.state.cartItems[i].bookCount - 1;
              if (that.state.cartItems[i].bookCount == 0) {
                that.fetchCartItems(that.state.token);
              }
            }
          }
          that.setState({});
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };
  showCartItem = ({item}) => {
    if (item.name != null) {
      return (
        <Card>
          <Card.Header
            title={'书名：' + item.name}
            extra={'作者：' + item.author}
          />
          <Card.Body>
            <View style={styles.container}>
              <Image source={{uri: item.image}} style={styles.image} />
              <View style={styles.Price_and_Count}>
                <Text style={styles.price}>{item.price + '元'}</Text>
                <Text style={styles.bookCount}>{'x' + item.bookCount}</Text>
                <View style={styles.add_and_decrease}>
                  <Button
                    size={'small'}
                    onPress={() => this.increaseItem(item.bookId)}>
                    增加
                  </Button>
                  <Button
                    size={'small'}
                    onPress={() => this.decreaseItem(item.bookId)}>
                    减少
                  </Button>
                </View>
              </View>
            </View>
          </Card.Body>
        </Card>
      );
    }
  };
  fetchCartItems = (token) => {
    console.log('fetchItems');
    let that = this;
    let formdata = new FormData();
    formdata.append('token', token);
    fetch(GETCART_URL, {
      method: 'POST',
      body: formdata,
    })
      .then((response) => response.json())
      .then((responseData) => {
        that.state.cartItems = responseData;
        let data = [];
        for (let i = 0; i < this.state.cartItems.length; i++) {
          data.push(this.state.cartItems[i].bookId);
          console.log(this.state.cartItems[i].bookId);
        }
        console.log(data);
        that.fetchBookList(data);
        that.setState({});
      })
      .catch((error) => {
        console.error(error);
      });
  };
  fetchBookList = (data) => {
    let that = this;
    let formdata = new FormData();
    console.log('fetch');
    formdata.append('books', data.toString());
    fetch(GETBOOKS_URL, {
      method: 'POST',
      body: formdata,
    })
      .then((response) => response.json())
      .then((responseData) => {
        for (let i = 0; i < responseData.length; i++) {
          that.state.cartItems[i].name = responseData[i].name;
          that.state.cartItems[i].author = responseData[i].author;
          that.state.cartItems[i].price = responseData[i].price;
          that.state.cartItems[i].image = responseData[i].image.base64;
        }
        that.setState({});
      })
      .catch((error) => {
        console.error(error);
      });
  };
  submitOrder = () => {
    let that = this;
    let formdata = new FormData();
    formdata.append('token', this.state.token);
    fetch(ADDORDER_URL, {
      method: 'POST',
      body: formdata,
    })
      .then((response) => response.json())
      .then((responseData) => {
        console.log(responseData);
        if (responseData == true) {
          Alert.alert('成功', '下单成功', [
            {text: '确定', onPress: () => console.log('点击确定')},
          ]);
          that.state.cartItems.splice(0, that.state.cartItems.length);
          that.setState({});
          let message = 'submit Order succesfully';
          DeviceEventEmitter.emit('submitOrder', message);
        } else {
          Alert.alert('失败', '下单失败，有书籍库存不足', [
            {text: '确定', onPress: () => console.log('点击确定')},
          ]);
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };
  render() {
    if (
      this.state.cartItems.length > 0 &&
      this.state.cartItems[0].name != null
    ) {
      return (
        <ScrollView>
          <Button type="primary" style={{margin: 10}} onPress={this.submitOrder}>
            下单
          </Button>
          <FlatList
            data={this.state.cartItems}
            renderItem={this.showCartItem}
            style={styles.list}
            keyExtractor={(item) => item.bookId}
          />
        </ScrollView>
      );
    } else if (this.state.cartItems.length == 0) {
      return null;
    } else {
      return (
        <View style={{flex: 1, paddingTop: 340}}>
          <ActivityIndicator />
        </View>
      );
    }
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    // backgroundColor: '#fff0f6',
  },
  image: {
    width: 65,
    height: 100,
  },
  list: {
    paddingLeft: 10,
    paddingRight: 5,
    backgroundColor: '#fff0f6',
  },
  price: {
    fontSize: 30,
    color: '#91d5ff',
  },
  bookCount: {
    fontSize: 20,
    marginLeft: 50,
    marginRight: 0,
  },
  Price_and_Count: {
    paddingRight: 0,
  },
  add_and_decrease: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});
