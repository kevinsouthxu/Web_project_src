import React from 'react';
import {View, ScrollView, Image, StyleSheet} from 'react-native';
import {Accordion, List} from '@ant-design/react-native';
export class BookDetailScreen extends React.Component {
  state = {
    activeSections: [2, 0],
  };
  onChange = (activeSections: number[]) => {
    this.setState({activeSections});
  };
  render() {
    // console.log(this.props.route.params.detail);
    let detail = this.props.route.params.detail;
    return (
      <ScrollView>
        <View style={styles.image_view}>
          <Image source={{uri: detail.image.base64}} style={styles.image} />
        </View>
        <Accordion
          onChange={this.onChange}
          activeSections={this.state.activeSections}>
          <Accordion.Panel header="书名">{detail.name}</Accordion.Panel>
          <Accordion.Panel header="作者">{detail.author}</Accordion.Panel>
          <Accordion.Panel header="ISBN">{detail.ISBN}</Accordion.Panel>
          <Accordion.Panel header="单价">{detail.price}</Accordion.Panel>
          <Accordion.Panel header="库存">{detail.repertory}</Accordion.Panel>
          <Accordion.Panel header="简介">{detail.information}</Accordion.Panel>
        </Accordion>
      </ScrollView>
    );
  }
}
const styles = StyleSheet.create({
  name: {
    fontSize: 20,
  },
  image_view: {
    alignItems: 'center',
  },
  image: {
    width: 182,
    height: 245,
  },
  description: {
    paddingLeft: 50,
    paddingRight: 55,
  },
});
