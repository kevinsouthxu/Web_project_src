import React from 'react';
import {View, ScrollView, Image, StyleSheet, Text, Alert} from 'react-native';
import {List, Button, WhiteSpace, Modal} from '@ant-design/react-native';
import AsyncStorage from '@react-native-community/async-storage';
import {apiUrl} from '../urlconfig';
const ADDCART_URL = apiUrl + '/addCart';
const Item = List.Item;
const Brief = Item.Brief;
export class BookDetailScreen extends React.Component {
  AddCart = (token, bookId) => {
    console.log('addCart');
    let formdata = new FormData();
    formdata.append('token', token);
    formdata.append('bookId', bookId);
    fetch(ADDCART_URL, {
      method: 'POST',
      body: formdata,
    })
      .then((response) => {
        return response.json();
      })
      .then((responseData) => {
        console.log(responseData);
        if (responseData == true) {
          //alert('成功加入购物车');
          Alert.alert('成功', '已将书籍加入购物车', [
            {text: '确定', onPress: () => console.log('点击确定')},
          ]);
        } else {
          Alert.alert('失败', '购物车已有该书籍', [
            {text: '确定', onPress: () => console.log('点击确定')},
          ]);
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };
  onAddCart = () => {
    let that = this;
    let token = 0;
    let detail = this.props.route.params.detail;
    AsyncStorage.getItem('token', function (error, result) {
      if (error) {
        alert('token读取失败');
      } else {
        token = result;
        console.log(token);
        console.log(detail.bookId);
        that.AddCart(parseInt(token), parseInt(detail.bookId));
      }
    });
  };
  render() {
    let detail = this.props.route.params.detail;
    return (
      <ScrollView>
        <View style={styles.image_view}>
          <Image source={{uri: detail.image.base64}} style={styles.image} />
        </View>
        <List renderHeader={'书籍信息'}>
          <Item data-seed="logId">
            <Text>书名：{detail.name}</Text>
          </Item>
          <Item data-seed="logId">
            <Text>作者：{detail.author}</Text>
          </Item>
          <Item data-seed="logId">
            <Text>ISBN：{detail.ISBN}</Text>
          </Item>
          <Item multipleLine>
            <Text>价格：{detail.price}</Text>
            <Brief>
              <Text>库存：{detail.repertory}</Text>
            </Brief>
          </Item>
          <Item wrap>
            <Text>简介：{detail.information}</Text>
          </Item>
        </List>
        <WhiteSpace />
        <Button style={{backgroundColor: '#bae7ff'}} onPress={this.onAddCart}>
          下单
        </Button>
        <WhiteSpace />
      </ScrollView>
    );
  }
}
const styles = StyleSheet.create({
  name: {
    fontSize: 20,
  },
  image_view: {
    alignItems: 'center',
  },
  image: {
    width: 182,
    height: 245,
  },
  description: {
    paddingLeft: 50,
    paddingRight: 55,
  },
});
