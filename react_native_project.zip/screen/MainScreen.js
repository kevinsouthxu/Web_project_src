import React from 'react';
import {View, Text} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {BookListScreen} from './BookListScreen';
import {BookDetailScreen} from './BookScreen';
import {SafeAreaProvider} from 'react-native-safe-area-context';
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
function MyCartScreen({navigation}) {
  return (
    <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Text>My Cart</Text>
    </View>
  );
}

function BookListAndDetail() {
  return (
    <SafeAreaProvider>
      <Stack.Navigator>
        <Stack.Screen
          name="BookList"
          component={BookListScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen name="BookDetail" component={BookDetailScreen} />
      </Stack.Navigator>
    </SafeAreaProvider>
  );
}

function MyOrderScreen({navigation}) {
  return (
    <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Text>My Order</Text>
    </View>
  );
}
export class MainScreen extends React.Component {
  render() {
    return (
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="书籍" component={BookListAndDetail} />
        <Drawer.Screen name="购物车" component={MyCartScreen} />
        <Drawer.Screen name="订单信息" component={MyOrderScreen} />
      </Drawer.Navigator>
    );
  }
}
