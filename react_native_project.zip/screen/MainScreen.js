import React from 'react';
import {View, Text} from 'react-native';
import {TabBar, Icon} from '@ant-design/react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {BookListScreen} from './BookListScreen';
import {BookDetailScreen} from './BookScreen';
import {SafeAreaProvider} from 'react-native-safe-area-context';
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
function MyCartScreen({navigation}) {
  return (
    <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Text>My Cart</Text>
    </View>
  );
}

function BookListAndDetail() {
  return (
    <SafeAreaProvider>
      <Stack.Navigator>
        <Stack.Screen
          name="BookList"
          component={BookListScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen name="BookDetail" component={BookDetailScreen} />
      </Stack.Navigator>
    </SafeAreaProvider>
  );
}

export class MainScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedTab: 'redTab',
    };
  }
  render() {
    return (
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="书籍" component={BookListAndDetail} />
        <Drawer.Screen name="购物车" component={MyCartScreen} />
      </Drawer.Navigator>
    );
  }
}
