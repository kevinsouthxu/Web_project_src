import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {BookListScreen} from './BookListScreen';
import {BookDetailScreen} from './BookScreen';
import {CartScreen} from './CartScreen';
import {SafeAreaProvider} from 'react-native-safe-area-context';
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

function BookListAndDetail() {
  return (
    <SafeAreaProvider>
      <Stack.Navigator>
        <Stack.Screen
          name="BookList"
          component={BookListScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen name="书籍详细页面" component={BookDetailScreen} />
      </Stack.Navigator>
    </SafeAreaProvider>
  );
}

export class MainScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedTab: 'redTab',
    };
  }
  render() {
    return (
      <Drawer.Navigator initialRouteName="首页">
        <Drawer.Screen name="首页" component={BookListAndDetail} />
        <Drawer.Screen name="购物车" component={CartScreen} />
      </Drawer.Navigator>
    );
  }
}
