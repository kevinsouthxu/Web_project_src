import React, {Component} from 'react';
import {LoginScreen} from './Login';
import {MainScreen} from './MainScreen';
import {NavigationContainer} from '@react-navigation/native';
// import {StackNavigator} from 'react-navigation';
import {createStackNavigator} from '@react-navigation/stack';

const SimpleAppNavigator = createStackNavigator();
export default class Pages extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <NavigationContainer>
        <SimpleAppNavigator.Navigator>
          <SimpleAppNavigator.Screen
            name="Login"
            component={LoginScreen}
            options={{headerShown: false}}
          />
          <SimpleAppNavigator.Screen
            name="Main"
            component={MainScreen}
            options={{headerShown: false}}
          />
        </SimpleAppNavigator.Navigator>
      </NavigationContainer>
    );
  }
}
